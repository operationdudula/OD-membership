-- Create paid_applicants table for verification information
CREATE TABLE public.paid_applicants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  id_number TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.paid_applicants ENABLE ROW LEVEL SECURITY;

-- Create policies for paid_applicants
CREATE POLICY "Anyone can view paid applicants" 
ON public.paid_applicants 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create paid applicants" 
ON public.paid_applicants 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update paid applicants" 
ON public.paid_applicants 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete paid applicants" 
ON public.paid_applicants 
FOR DELETE 
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_paid_applicants_updated_at
BEFORE UPDATE ON public.paid_applicants
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();