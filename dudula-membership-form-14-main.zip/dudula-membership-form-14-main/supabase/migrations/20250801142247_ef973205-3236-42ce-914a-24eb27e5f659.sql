-- Allow null values for card_number initially (will be generated upon activation)
ALTER TABLE applications ALTER COLUMN card_number DROP NOT NULL;

-- Also update other league tables to allow null card numbers initially
ALTER TABLE mens_league_memberships ALTER COLUMN operation_dudula_card_number DROP NOT NULL;
ALTER TABLE womens_league_memberships ALTER COLUMN operation_dudula_card_number DROP NOT NULL;
ALTER TABLE youth_league_memberships ALTER COLUMN operation_dudula_card_number DROP NOT NULL;