-- Create youth league memberships table
CREATE TABLE public.youth_league_memberships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  operation_dudula_card_number TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  id_number TEXT NOT NULL,
  signature TEXT NOT NULL,
  membership_status TEXT NOT NULL DEFAULT 'pending',
  submitted_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '5 years'),
  activated BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create mens league memberships table
CREATE TABLE public.mens_league_memberships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  operation_dudula_card_number TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  id_number TEXT NOT NULL,
  signature TEXT NOT NULL,
  membership_status TEXT NOT NULL DEFAULT 'pending',
  submitted_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '5 years'),
  activated BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.youth_league_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mens_league_memberships ENABLE ROW LEVEL SECURITY;

-- Create policies for youth league memberships
CREATE POLICY "Anyone can view youth league memberships" 
ON public.youth_league_memberships 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create youth league memberships" 
ON public.youth_league_memberships 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update youth league memberships" 
ON public.youth_league_memberships 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete youth league memberships" 
ON public.youth_league_memberships 
FOR DELETE 
USING (true);

-- Create policies for mens league memberships
CREATE POLICY "Anyone can view mens league memberships" 
ON public.mens_league_memberships 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create mens league memberships" 
ON public.mens_league_memberships 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update mens league memberships" 
ON public.mens_league_memberships 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete mens league memberships" 
ON public.mens_league_memberships 
FOR DELETE 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_youth_league_memberships_updated_at
  BEFORE UPDATE ON public.youth_league_memberships
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_mens_league_memberships_updated_at
  BEFORE UPDATE ON public.mens_league_memberships
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create applications table to store Operation Dudula applications
CREATE TABLE public.applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  card_number TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  nationality TEXT NOT NULL,
  alternative_number TEXT,
  mobile_number TEXT NOT NULL,
  id_number TEXT NOT NULL,
  gender TEXT NOT NULL,
  race TEXT NOT NULL,
  period TEXT NOT NULL,
  employed TEXT NOT NULL,
  qualification TEXT NOT NULL,
  address_line1 TEXT NOT NULL,
  address_line2 TEXT NOT NULL,
  address_line3 TEXT,
  ward_no TEXT NOT NULL,
  province TEXT NOT NULL,
  sub_region TEXT NOT NULL,
  membership_status TEXT NOT NULL DEFAULT 'pending',
  signature TEXT NOT NULL,
  submitted_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  activated BOOLEAN NOT NULL DEFAULT false,
  declaration_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;

-- Create policies for applications
CREATE POLICY "Anyone can view applications" 
ON public.applications 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create applications" 
ON public.applications 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update applications" 
ON public.applications 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete applications" 
ON public.applications 
FOR DELETE 
USING (true);

-- Create trigger for automatic timestamp updates on applications
CREATE TRIGGER update_applications_updated_at
  BEFORE UPDATE ON public.applications
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();