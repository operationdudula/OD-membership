-- Create womens league memberships table
CREATE TABLE public.womens_league_memberships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  operation_dudula_card_number TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  id_number TEXT NOT NULL,
  signature TEXT NOT NULL,
  membership_status TEXT NOT NULL DEFAULT 'pending',
  activated BOOLEAN NOT NULL DEFAULT false,
  submitted_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + INTERVAL '5 years'),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.womens_league_memberships ENABLE ROW LEVEL SECURITY;

-- Create policies for womens league memberships (public access for form submissions)
CREATE POLICY "Anyone can view womens league memberships" 
ON public.womens_league_memberships 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create womens league memberships" 
ON public.womens_league_memberships 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update womens league memberships" 
ON public.womens_league_memberships 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete womens league memberships" 
ON public.womens_league_memberships 
FOR DELETE 
USING (true);

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_womens_league_memberships_updated_at
BEFORE UPDATE ON public.womens_league_memberships
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();