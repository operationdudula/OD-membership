import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

interface SuccessMessageProps {
  onNewApplication: () => void;
}

export function SuccessMessage({ onNewApplication }: SuccessMessageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center">
      <Card className="w-full max-w-md shadow-xl border-0 bg-white/95 backdrop-blur">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <CheckCircle className="h-16 w-16 text-success" />
          </div>
          <CardTitle className="text-xl font-bold text-primary">
            Application Submitted Successfully!
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            Thank you patriot for joining Operation Dudula. Your application has been received and is being processed.
          </p>
          <p className="text-sm text-muted-foreground">
            You will receive an email confirmation with your membership details once your application is approved.
          </p>
          <Button 
            onClick={onNewApplication}
            className="w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-dark hover:to-primary"
          >
            Submit Another Application
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}