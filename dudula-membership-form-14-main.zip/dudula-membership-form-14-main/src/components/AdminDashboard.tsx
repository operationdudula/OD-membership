import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { EmailComposer } from '@/components/EmailComposer';
import { AdminManagement } from '@/components/AdminManagement';
import { SuperAdminManagement } from '@/components/SuperAdminManagement';
import { ApplicationViewer } from '@/components/ApplicationViewer';
import { RegionalDownloads } from '@/components/RegionalDownloads';
import { Eye, Upload, Trash2, X, ExternalLink, Users } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import * as XLSX from 'xlsx';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF6B6B', '#4ECDC4'];

interface Application {
  id: string;
  cardNumber: string;
  operationDudulaCardNumber?: string;
  firstName: string;
  lastName: string;
  email: string;
  nationality: string;
  alternativeNumber?: string;
  mobileNumber: string;
  idNumber: string;
  gender: string;
  race: string;
  period: string;
  employed: string;
  qualification: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3?: string;
  wardNo: string;
  province: string;
  subRegion: string;
  membershipStatus: string;
  signature: string;
  submittedDate: string;
  activated: boolean;
  verified?: boolean;
  declarationName?: string;
}

interface AdminDashboardProps {
  applications: Application[];
  onActivateApplication: (id: string) => void;
  onDeleteApplication: (id: string) => void;
  onLogout: () => void;
}

export function AdminDashboard({ applications, onActivateApplication, onDeleteApplication, onLogout }: AdminDashboardProps) {
  const [embedCode, setEmbedCode] = useState('');
  const [emailComposerOpen, setEmailComposerOpen] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
  const [applicationViewerOpen, setApplicationViewerOpen] = useState(false);
  const [viewingApplication, setViewingApplication] = useState<Application | null>(null);
  const [organizationLogo, setOrganizationLogo] = useState<string>('');
  const [sendgridApiKey, setSendgridApiKey] = useState<string>('');
  const [customPaymentLink, setCustomPaymentLink] = useState<string>('');
  const [emailPlatform, setEmailPlatform] = useState<string>('gmail');
  const [customEmailPlatformUrl, setCustomEmailPlatformUrl] = useState('');
  const [paymentShortCode, setPaymentShortCode] = useState('');
  const [returnUrl, setReturnUrl] = useState('');
  const [cancelUrl, setCancelUrl] = useState('');
  const [notifyUrl, setNotifyUrl] = useState('');
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [paymentNotifications, setPaymentNotifications] = useState<any[]>([]);
  const [recentAppsSearchTerm, setRecentAppsSearchTerm] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const baseUrl = window.location.origin;
    const embedHtml = `<iframe src="${baseUrl}" width="100%" height="800" frameborder="0"></iframe>`;
    setEmbedCode(embedHtml);

    // Check admin type
    const adminType = localStorage.getItem('dudula-admin-type');
    setIsSuperAdmin(adminType === 'super');

    // Load saved settings from localStorage
    const savedLogo = localStorage.getItem('dudula-org-logo');
    const savedApiKey = localStorage.getItem('dudula-sendgrid-api-key');
    const savedPaymentLink = localStorage.getItem('dudula-custom-payment-link');
    const savedEmailPlatform = localStorage.getItem('dudula-email-platform');
    const savedCustomUrl = localStorage.getItem('dudula-custom-email-url');
    const savedShortCode = localStorage.getItem('dudula-payment-shortcode');
    const savedReturnUrl = localStorage.getItem('dudula-return-url');
    const savedCancelUrl = localStorage.getItem('dudula-cancel-url');
    const savedNotifyUrl = localStorage.getItem('dudula-notify-url');
    const savedNotifications = localStorage.getItem('dudula-payment-notifications');
    
    if (savedLogo) setOrganizationLogo(savedLogo);
    if (savedApiKey) setSendgridApiKey(savedApiKey);
    if (savedPaymentLink) setCustomPaymentLink(savedPaymentLink);
    if (savedEmailPlatform) setEmailPlatform(savedEmailPlatform);
    if (savedCustomUrl) setCustomEmailPlatformUrl(savedCustomUrl);
    if (savedShortCode) setPaymentShortCode(savedShortCode);
    if (savedReturnUrl) setReturnUrl(savedReturnUrl);
    if (savedCancelUrl) setCancelUrl(savedCancelUrl);
    if (savedNotifyUrl) setNotifyUrl(savedNotifyUrl);
    if (savedNotifications) setPaymentNotifications(JSON.parse(savedNotifications));
  }, []);

  const downloadExcel = () => {
    const exportData = applications.map(app => ({
      'Card Number': app.cardNumber,
      'First Name': app.firstName,
      'Last Name': app.lastName,
      'Email': app.email,
      'Nationality': app.nationality,
      'Alternative Number': app.alternativeNumber || '',
      'Mobile Number': app.mobileNumber,
      'ID Number': app.idNumber,
      'Gender': app.gender,
      'Race': app.race,
      'Period': app.period,
      'Employed': app.employed,
      'Qualification': app.qualification,
      'Address Line 1': app.addressLine1,
      'Address Line 2': app.addressLine2,
      'Address Line 3': app.addressLine3 || '',
      'Ward No': app.wardNo,
      'Province': app.province,
      'Sub Region': app.subRegion,
      'Membership Status': app.membershipStatus,
      'Submitted Date': app.submittedDate,
      'Activated': app.activated ? 'Yes' : 'No'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Applications');
    XLSX.writeFile(wb, `operation-dudula-applications-${new Date().toISOString().split('T')[0]}.xlsx`);
    
    toast({
      title: "Export Successful",
      description: "Applications exported to Excel file",
    });
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const logoDataUrl = e.target?.result as string;
        setOrganizationLogo(logoDataUrl);
        localStorage.setItem('dudula-org-logo', logoDataUrl);
        toast({
          title: "Logo Uploaded",
          description: "Organization logo has been updated",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveLogo = () => {
    setOrganizationLogo('');
    localStorage.removeItem('dudula-org-logo');
    toast({
      title: "Logo Removed",
      description: "Organization logo has been removed",
    });
  };

  const copyEmbedCode = () => {
    navigator.clipboard.writeText(embedCode);
    toast({
      title: "Copied",
      description: "Embed code copied to clipboard",
    });
  };

  const handleActivateClick = (application: Application) => {
    setSelectedApplication(application);
    setEmailComposerOpen(true);
  };

  const handleSendEmail = async (application: Application, emailData: any) => {
    try {
      // Generate card number upon activation
      const cardNumber = `OD${Date.now()}`;
      
      // Update application with card number in Supabase
      try {
        const { error: updateError } = await supabase
          .from('applications')
          .update({ card_number: cardNumber })
          .eq('id', application.id);

        if (updateError) {
          console.error('Failed to update card number in Supabase:', updateError);
        }
      } catch (supabaseError) {
        console.error('Supabase update error:', supabaseError);
      }

      // Update email data to include card number
      const updatedEmailData = {
        ...emailData,
        message: emailData.message.replace('${application.cardNumber}', cardNumber)
      };

      if (emailPlatform === 'sendgrid' && sendgridApiKey) {
        await sendEmailViaSendGrid(application, updatedEmailData);
      } else {
        openEmailPlatform(application, updatedEmailData);
      }
      onActivateApplication(application.id);
      toast({
        title: "Application Activated",
        description: `${application.firstName} ${application.lastName}'s application has been activated with card number: ${cardNumber}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send activation email. Please try again.",
        variant: "destructive",
      });
    }
  };

  const openEmailPlatform = (application: Application, emailData: any) => {
    const { subject, message } = emailData;
    const encodedSubject = encodeURIComponent(subject);
    const encodedBody = encodeURIComponent(message);
    const recipientEmail = application.email;

    let platformUrl = '';

    switch (emailPlatform) {
      case 'gmail':
        platformUrl = `https://mail.google.com/mail/?view=cm&to=${recipientEmail}&su=${encodedSubject}&body=${encodedBody}`;
        break;
      case 'outlook':
        platformUrl = `https://outlook.live.com/mail/0/deeplink/compose?to=${recipientEmail}&subject=${encodedSubject}&body=${encodedBody}`;
        break;
      case 'yahoo':
        platformUrl = `https://compose.mail.yahoo.com/?to=${recipientEmail}&subject=${encodedSubject}&body=${encodedBody}`;
        break;
      case 'protonmail':
        platformUrl = `https://mail.proton.me/compose?to=${recipientEmail}&subject=${encodedSubject}&body=${encodedBody}`;
        break;
      case 'apple':
        platformUrl = `mailto:${recipientEmail}?subject=${encodedSubject}&body=${encodedBody}`;
        break;
      case 'thunderbird':
        platformUrl = `mailto:${recipientEmail}?subject=${encodedSubject}&body=${encodedBody}`;
        break;
      case 'mailchimp':
        platformUrl = `https://mailchimp.com/help/compose-emails/`;
        break;
      case 'constant-contact':
        platformUrl = `https://www.constantcontact.com/`;
        break;
      case 'sendgrid':
        platformUrl = `https://sendgrid.com/`;
        break;
      case 'custom':
        if (customEmailPlatformUrl) {
          platformUrl = customEmailPlatformUrl.replace('{email}', recipientEmail)
                                              .replace('{subject}', encodedSubject)
                                              .replace('{body}', encodedBody);
        }
        break;
      default:
        platformUrl = `mailto:${recipientEmail}?subject=${encodedSubject}&body=${encodedBody}`;
    }

    if (platformUrl) {
      window.open(platformUrl, '_blank');
    }
  };

  const sendEmailViaSendGrid = async (application: Application, emailData: any) => {
    if (!sendgridApiKey) {
      throw new Error('SendGrid API key not configured');
    }

    const emailPayload = {
      personalizations: [{
        to: [{ email: application.email, name: `${application.firstName} ${application.lastName}` }],
        subject: emailData.subject
      }],
      from: { email: 'noreply@operationdudula.org', name: 'Operation Dudula' },
      content: [{
        type: 'text/html',
        value: emailData.message
      }]
    };

    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${sendgridApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(emailPayload)
    });

    if (!response.ok) {
      throw new Error('Failed to send email');
    }
  };

  const handleViewApplication = (application: Application) => {
    setViewingApplication(application);
    setApplicationViewerOpen(true);
  };

  const handleDeleteApplication = async (applicationId: string) => {
    if (window.confirm('Are you sure you want to delete this application? This action cannot be undone.')) {
      try {
        // Try to delete from Supabase first
        const { error: mainError } = await supabase
          .from('applications')
          .delete()
          .eq('id', applicationId);

        const { error: mensError } = await supabase
          .from('mens_league_memberships')
          .delete()
          .eq('id', applicationId);

        const { error: womensError } = await supabase
          .from('womens_league_memberships')
          .delete()
          .eq('id', applicationId);

        const { error: youthError } = await supabase
          .from('youth_league_memberships')
          .delete()
          .eq('id', applicationId);

        // Call the parent deletion handler
        onDeleteApplication(applicationId);
        
        toast({
          title: "Application Deleted",
          description: "The application has been successfully deleted",
        });
      } catch (error) {
        console.error('Error deleting application:', error);
        // Still call parent deletion for localStorage fallback
        onDeleteApplication(applicationId);
        
        toast({
          title: "Application Deleted",
          description: "The application has been deleted from local storage",
        });
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-primary">Operation Dudula Admin Dashboard</h1>
            {isSuperAdmin && (
              <p className="text-sm text-muted-foreground">Super Admin Access</p>
            )}
          </div>
          <Button variant="outline" onClick={onLogout}>
            Logout
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{applications.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Activated</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">
                {applications.filter(app => app.activated).length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">
                {applications.filter(app => !app.activated).length}
              </div>
            </CardContent>
          </Card>
          
          <Card 
            className="cursor-pointer hover:bg-accent/50 transition-colors"
            onClick={() => window.location.href = '/admin/paid-applicants'}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Paid Applicants</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">View</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button onClick={downloadExcel} size="sm" className="w-full">
                Export Excel
              </Button>
              <Button 
                onClick={() => window.location.href = '/activated-applicants'}
                size="sm" 
                className="w-full flex items-center gap-2"
                variant="outline"
              >
                <Users className="h-4 w-4" />
                Activated Applicants
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Applications by Province</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={Object.entries(
                        applications.reduce((acc, app) => {
                          acc[app.province] = (acc[app.province] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>)
                      ).map(([name, value]) => ({ name, value }))}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {Object.entries(
                        applications.reduce((acc, app) => {
                          acc[app.province] = (acc[app.province] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>)
                      ).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Applications by Province Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button 
                  variant="outline" 
                  onClick={() => window.location.href = '/applications-by-province'}
                  className="w-full flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  View Detailed Province Analytics
                </Button>
                <p className="text-sm text-muted-foreground">
                  View comprehensive province-wise application analytics and regional performance data.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Recent Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Input
                  placeholder="Search by ID number, email, or mobile number..."
                  value={recentAppsSearchTerm}
                  onChange={(e) => setRecentAppsSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <div className="space-y-6 max-h-96 overflow-y-auto">
                {Object.entries(
                  applications
                    .filter(app => 
                      recentAppsSearchTerm === '' || 
                      (app.idNumber && app.idNumber.toLowerCase().includes(recentAppsSearchTerm.toLowerCase())) ||
                      (app.email && app.email.toLowerCase().includes(recentAppsSearchTerm.toLowerCase())) ||
                      (app.mobileNumber && app.mobileNumber.toLowerCase().includes(recentAppsSearchTerm.toLowerCase()))
                    )
                    .reduce((acc, app) => {
                      if (!acc[app.province]) {
                        acc[app.province] = [];
                      }
                      acc[app.province].push(app);
                      return acc;
                    }, {} as Record<string, typeof applications>)
                ).map(([province, provinceApps]) => (
                  <div key={province} className="border rounded-lg p-4">
                    <h3 className="font-semibold text-primary mb-3 flex items-center gap-2">
                      {province} 
                      <Badge variant="outline">{provinceApps.length}</Badge>
                    </h3>
                    <div className="space-y-3">
                      {provinceApps.map((app) => (
                        <div key={app.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <div className={`w-3 h-3 rounded-full ${app.membershipStatus === 'verified' || app.verified ? 'bg-green-500' : 'bg-red-500'}`}></div>
                              <div className="font-medium">{app.firstName} {app.lastName}</div>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Card: {app.cardNumber || app.operationDudulaCardNumber || 'Not assigned'} | {app.email}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Submitted: {new Date(app.submittedDate).toLocaleDateString()} | {app.subRegion}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={app.activated ? "default" : "secondary"}>
                              {app.activated ? "Activated" : "Pending"}
                            </Badge>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleViewApplication(app)}
                              className="flex items-center gap-1"
                            >
                              <Eye className="h-3 w-3" />
                              View
                            </Button>
                            {!app.activated && (
                              <Button
                                size="sm"
                                onClick={() => handleActivateClick(app)}
                                className="bg-success hover:bg-success/90"
                              >
                                Activate
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteApplication(app.id)}
                              className="flex items-center gap-1"
                            >
                              <Trash2 className="h-3 w-3" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            {/* League Applications Management */}
            <Card>
              <CardHeader>
                <CardTitle>League Applications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.location.href = '/admin/mens-league-applications'}
                >
                  View Men's League Applications
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.location.href = '/admin/womens-league-applications'}
                >
                  View Women's League Applications
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.location.href = '/admin/youth-league-applications'}
                >
                  View Youth League Applications
                </Button>
              </CardContent>
            </Card>

            {/* Admin Management */}
            {isSuperAdmin ? <SuperAdminManagement /> : <AdminManagement />}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* League Application Links */}
          <Card>
            <CardHeader>
              <CardTitle>League Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/mens-league-applications'}
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  Men's League
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/womens-league-applications'}
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  Women's League
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/youth-league-applications'}
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  Youth League
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Regional Downloads */}
          <RegionalDownloads />
        </div>

      </div>
      
      {selectedApplication && (
        <EmailComposer
          isOpen={emailComposerOpen}
          onClose={() => setEmailComposerOpen(false)}
          application={selectedApplication}
          onSendEmail={handleSendEmail}
        />
      )}
      
      {viewingApplication && (
        <ApplicationViewer
          isOpen={applicationViewerOpen}
          onClose={() => setApplicationViewerOpen(false)}
          application={viewingApplication}
        />
      )}
    </div>
  );
}