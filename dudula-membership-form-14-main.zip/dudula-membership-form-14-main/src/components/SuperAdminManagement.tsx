import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trash2, UserPlus } from 'lucide-react';

interface Admin {
  id: string;
  username: string;
  password: string;
  createdDate: string;
  type: 'super' | 'regular';
}

export function SuperAdminManagement() {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAdmins();
  }, []);

  const loadAdmins = () => {
    const savedAdmins = localStorage.getItem('dudula-admins');
    if (savedAdmins) {
      const adminsList = JSON.parse(savedAdmins);
      // Add type to existing admins if not present
      const updatedAdmins = adminsList.map((admin: any) => ({
        ...admin,
        type: admin.username === 'khangwelo' ? 'super' : 'regular'
      }));
      setAdmins(updatedAdmins);
      localStorage.setItem('dudula-admins', JSON.stringify(updatedAdmins));
    }
  };

  const createNewAdmin = () => {
    if (!newUsername.trim() || !newPassword.trim()) {
      toast({
        title: "Error",
        description: "Please fill in both username and password",
        variant: "destructive",
      });
      return;
    }

    // Check if username already exists
    const existingAdmin = admins.find(admin => admin.username === newUsername);
    if (existingAdmin) {
      toast({
        title: "Error",
        description: "Username already exists",
        variant: "destructive",
      });
      return;
    }

    const newAdmin: Admin = {
      id: Date.now().toString(),
      username: newUsername,
      password: newPassword,
      createdDate: new Date().toISOString(),
      type: 'regular'
    };

    const updatedAdmins = [...admins, newAdmin];
    setAdmins(updatedAdmins);
    localStorage.setItem('dudula-admins', JSON.stringify(updatedAdmins));

    setNewUsername('');
    setNewPassword('');
    setDialogOpen(false);

    toast({
      title: "Success",
      description: `Admin '${newUsername}' created successfully`,
    });
  };

  const deleteAdmin = (adminId: string) => {
    const adminToDelete = admins.find(admin => admin.id === adminId);
    
    // Prevent deletion of super admin
    if (adminToDelete?.username === 'khangwelo') {
      toast({
        title: "Error",
        description: "Cannot delete the super admin account",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Are you sure you want to delete admin '${adminToDelete?.username}'?`)) {
      const updatedAdmins = admins.filter(admin => admin.id !== adminId);
      setAdmins(updatedAdmins);
      localStorage.setItem('dudula-admins', JSON.stringify(updatedAdmins));

      toast({
        title: "Success",
        description: "Admin deleted successfully",
      });
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Admin Management (Super Admin Only)</CardTitle>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Admin
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Admin</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="new-username">Username</Label>
                <Input
                  id="new-username"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="Enter username"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="new-password">Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter password"
                  className="mt-1"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={createNewAdmin}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Create Admin
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {admins.map((admin) => (
            <div key={admin.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium">{admin.username}</p>
                <div className="flex gap-2 items-center">
                  <span className={`px-2 py-1 rounded text-xs ${
                    admin.type === 'super' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'
                  }`}>
                    {admin.type === 'super' ? 'Super Admin' : 'Regular Admin'}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Created: {new Date(admin.createdDate).toLocaleDateString()}
                  </span>
                </div>
              </div>
              {admin.username !== 'khangwelo' && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => deleteAdmin(admin.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}