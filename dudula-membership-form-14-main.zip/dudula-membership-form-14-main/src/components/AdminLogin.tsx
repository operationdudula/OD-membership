import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface AdminLoginProps {
  onLogin: () => void;
}

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Get stored admins from localStorage
    const savedAdmins = localStorage.getItem('dudula-admins');
    let admins = [];
    
    if (savedAdmins) {
      admins = JSON.parse(savedAdmins);
    } else {
      // Set default admins to match AdminManagement
      const defaultAdmins = [
        {
          id: '1',
          username: 'admin',
          password: 'password',
          createdDate: new Date().toISOString()
        },
        {
          id: '2',
          username: 'khangwelo',
          password: 'khangwelo',
          createdDate: new Date().toISOString()
        },
        {
          id: '3',
          username: 'operationdudula123',
          password: 'Operationdudula@123',
          createdDate: new Date().toISOString()
        },
        {
          id: '4',
          username: 'Zandile Dabula',
          password: 'Zandiledabula@123',
          createdDate: new Date().toISOString()
        },
        {
          id: '5',
          username: 'khangwi',
          password: 'khangwi',
          createdDate: new Date().toISOString()
        }
      ];
      admins = defaultAdmins;
      localStorage.setItem('dudula-admins', JSON.stringify(defaultAdmins));
    }
    
    // Check if credentials match any admin
    const validAdmin = admins.find((admin: any) => 
      admin.username === username && admin.password === password
    );
    
    if (validAdmin) {
      // Store admin type in localStorage
      const isSuper = validAdmin.username === 'khangwelo';
      localStorage.setItem('dudula-admin-type', isSuper ? 'super' : 'regular');
      localStorage.setItem('dudula-current-admin', JSON.stringify(validAdmin));
      
      toast({
        title: "Login Successful",
        description: `Welcome to the admin dashboard${isSuper ? ' (Super Admin)' : ''}`,
      });
      onLogin();
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid username or password",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <div className="mb-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/')}
            className="flex items-center gap-2 bg-white/80 backdrop-blur"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Form
          </Button>
        </div>
        
        <Card className="w-full shadow-xl border-0 bg-white/95 backdrop-blur">
        <CardHeader className="bg-gradient-to-r from-primary to-primary-light text-white rounded-t-lg">
          <CardTitle className="text-xl font-bold text-center">
            Operation Dudula Admin Login
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="mt-1"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1"
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-dark hover:to-primary"
            >
              Login
            </Button>
          </form>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}