import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Search } from 'lucide-react';

interface WomensLeagueStatusCheckerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WomensLeagueStatusChecker({ isOpen, onClose }: WomensLeagueStatusCheckerProps) {
  const [searchData, setSearchData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    idNumber: ''
  });
  const [applicationStatus, setApplicationStatus] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!searchData.firstName || !searchData.lastName || !searchData.email || !searchData.idNumber) {
      toast({
        title: "All Fields Required",
        description: "Please fill in all fields to check your status",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    try {
      const { data, error } = await supabase
        .from('womens_league_memberships')
        .select('*')
        .eq('first_name', searchData.firstName)
        .eq('last_name', searchData.lastName)
        .eq('email', searchData.email)
        .eq('id_number', searchData.idNumber)
        .single();

      if (error || !data) {
        toast({
          title: "Application Not Found",
          description: "No application found with the provided details",
          variant: "destructive",
        });
        setApplicationStatus(null);
      } else {
        setApplicationStatus(data);
        toast({
          title: "Application Found",
          description: "Your application status has been retrieved",
        });
      }
    } catch (error) {
      console.error('Error searching application:', error);
      toast({
        title: "Search Failed",
        description: "Failed to search for application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setSearchData(prev => ({ ...prev, [field]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader>
          <CardTitle>Check Women's League Application Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="firstName">First Name</Label>
            <Input
              id="firstName"
              value={searchData.firstName}
              onChange={(e) => handleInputChange('firstName', e.target.value)}
              placeholder="Enter your first name"
            />
          </div>
          
          <div>
            <Label htmlFor="lastName">Last Name</Label>
            <Input
              id="lastName"
              value={searchData.lastName}
              onChange={(e) => handleInputChange('lastName', e.target.value)}
              placeholder="Enter your last name"
            />
          </div>
          
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={searchData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="Enter your email"
            />
          </div>
          
          <div>
            <Label htmlFor="idNumber">ID Number</Label>
            <Input
              id="idNumber"
              value={searchData.idNumber}
              onChange={(e) => handleInputChange('idNumber', e.target.value)}
              placeholder="Enter your ID number"
            />
          </div>

          {applicationStatus && (
            <div className="bg-muted/50 p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Application Status</h4>
              <div className="space-y-2 text-sm">
                <p><strong>Name:</strong> {applicationStatus.first_name} {applicationStatus.last_name}</p>
                <p><strong>Email:</strong> {applicationStatus.email}</p>
                <p><strong>Card Number:</strong> {applicationStatus.operation_dudula_card_number || 'Not assigned'}</p>
                <p><strong>Status:</strong> 
                  <span className={`ml-2 px-2 py-1 rounded text-xs ${
                    applicationStatus.membership_status === 'verified' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {applicationStatus.membership_status === 'verified' ? 'Paid' : 'Unpaid'}
                  </span>
                </p>
                <p><strong>Submitted:</strong> {new Date(applicationStatus.submitted_date).toLocaleDateString()}</p>
                <p><strong>Activated:</strong> {applicationStatus.activated ? 'Yes' : 'No'}</p>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button onClick={handleSearch} disabled={isSearching}>
              <Search className="h-4 w-4 mr-2" />
              {isSearching ? 'Searching...' : 'Check Status'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}