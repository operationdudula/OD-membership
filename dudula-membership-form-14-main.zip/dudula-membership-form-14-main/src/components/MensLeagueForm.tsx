import React, { useState, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import SignatureCanvas from 'react-signature-canvas';
import { supabase } from '@/integrations/supabase/client';

const formSchema = z.object({
  operationDudulaCardNumber: z.string().min(1, 'Operation Dudula card number is required'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  email: z.string().email('Invalid email address'),
  idNumber: z.string().min(1, 'ID number is required'),
});

interface MensLeagueFormProps {
  onSubmit: (data: any) => void;
}

export const MensLeagueForm: React.FC<MensLeagueFormProps> = ({ onSubmit }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [signatureDataUrl, setSignatureDataUrl] = useState<string>('');
  const signatureRef = useRef<SignatureCanvas>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      operationDudulaCardNumber: '',
      firstName: '',
      lastName: '',
      email: '',
      idNumber: '',
    },
  });

  const clearSignature = () => {
    if (signatureRef.current) {
      signatureRef.current.clear();
      setSignatureDataUrl('');
    }
  };

  const handleSignatureEnd = () => {
    if (signatureRef.current) {
      const dataUrl = signatureRef.current.toDataURL();
      setSignatureDataUrl(dataUrl);
    }
  };

  const checkOperationDudulaApplication = async (cardNumber: string) => {
    // Check in database first
    const { data: dbApplications } = await supabase
      .from('applications')
      .select('card_number')
      .eq('card_number', cardNumber)
      .single();

    if (dbApplications) {
      return true;
    }

    // Check in localStorage as fallback
    const localApplications = JSON.parse(localStorage.getItem('dudula-applications') || '[]');
    return localApplications.some((app: any) => app.cardNumber === cardNumber);
  };

  const handleSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!signatureDataUrl) {
      toast({
        title: "Signature Required",
        description: "Please provide your signature before submitting.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // Verify Operation Dudula application exists
      const hasOperationDudulaApplication = await checkOperationDudulaApplication(values.operationDudulaCardNumber);
      
      if (!hasOperationDudulaApplication) {
        toast({
          title: "Application Not Found",
          description: "You must have an approved Operation Dudula membership application to apply for Men's League membership.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Check if already applied for Men's League
      const { data: existingApplication } = await supabase
        .from('mens_league_memberships')
        .select('id')
        .eq('operation_dudula_card_number', values.operationDudulaCardNumber)
        .single();

      if (existingApplication) {
        toast({
          title: "Already Applied",
          description: "You have already applied for Men's League membership with this card number.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      const applicationData = {
        operation_dudula_card_number: values.operationDudulaCardNumber,
        first_name: values.firstName,
        last_name: values.lastName,
        email: values.email,
        id_number: values.idNumber,
        signature: signatureDataUrl,
        membership_status: 'pending',
      };

      const { error } = await supabase
        .from('mens_league_memberships')
        .insert([applicationData]);

      if (error) {
        console.error('Error saving application:', error);
        toast({
          title: "Error",
          description: "Failed to submit application. Please try again.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      onSubmit(applicationData);
      
    } catch (error) {
      console.error('Error submitting application:', error);
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-xl border-0 bg-card/95 backdrop-blur">
            <CardHeader className="text-center bg-gradient-to-r from-primary to-primary-foreground text-primary-foreground rounded-t-lg">
              <CardTitle className="text-2xl font-bold">
                Men's League Membership Application
              </CardTitle>
              <p className="text-primary-foreground/90">
                Join the Men's League - Membership valid for 5 years
              </p>
            </CardHeader>
            <CardContent className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="operationDudulaCardNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Operation Dudula Card Number *</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your Operation Dudula card number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address *</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name *</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your first name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name *</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your last name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="idNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ID Number *</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your ID number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Signature Section */}
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium leading-none">
                        Digital Signature *
                      </label>
                      <p className="text-sm text-muted-foreground mb-2">
                        Please sign in the box below
                      </p>
                    </div>
                    <div className="border rounded-lg p-4 bg-background">
                      <SignatureCanvas
                        ref={signatureRef}
                        canvasProps={{
                          width: 500,
                          height: 200,
                          className: 'signature-canvas border rounded w-full',
                          style: { border: '1px solid #e2e8f0' }
                        }}
                        onEnd={handleSignatureEnd}
                      />
                      <div className="mt-2 flex justify-end">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={clearSignature}
                        >
                          Clear Signature
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6">
                    <Button
                      type="submit"
                      className="w-full bg-primary hover:bg-primary/90"
                      disabled={isLoading}
                    >
                      {isLoading ? 'Submitting...' : 'Submit Men\'s League Application'}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};