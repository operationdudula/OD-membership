import React from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Download } from 'lucide-react';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableCell, TableRow, WidthType, ImageRun } from 'docx';

interface Application {
  id: string;
  cardNumber?: string;
  card_number?: string;
  firstName?: string;
  first_name?: string;
  lastName?: string;
  last_name?: string;
  email: string;
  nationality?: string;
  alternativeNumber?: string;
  alternative_number?: string;
  mobileNumber?: string;
  mobile_number?: string;
  idNumber?: string;
  id_number?: string;
  gender?: string;
  race?: string;
  period?: string;
  employed?: string;
  qualification?: string;
  addressLine1?: string;
  address_line1?: string;
  addressLine2?: string;
  address_line2?: string;
  addressLine3?: string;
  address_line3?: string;
  wardNo?: string;
  ward_no?: string;
  province?: string;
  subRegion?: string;
  sub_region?: string;
  membershipStatus?: string;
  membership_status?: string;
  signature: string;
  submittedDate?: string;
  submitted_date?: string;
  activated: boolean;
  declarationName?: string;
  declaration_name?: string;
  operation_dudula_card_number?: string;
}

interface ApplicationViewerProps {
  isOpen: boolean;
  onClose: () => void;
  application: Application;
}

export function ApplicationViewer({ isOpen, onClose, application }: ApplicationViewerProps) {
  // Helper function to get field value from either camelCase or snake_case
  const getField = (field1: string, field2?: string) => {
    return (application as any)[field1] || (application as any)[field2!] || '';
  };

  const exportToWord = async () => {
    // Convert signature from base64 to buffer for Word document
    let signatureImageRun = null;
    if (application.signature) {
      try {
        const response = await fetch(application.signature);
        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);
        
        signatureImageRun = new ImageRun({
          data: uint8Array,
          transformation: {
            width: 200,
            height: 100,
          },
          type: "png",
        });
      } catch (error) {
        console.error('Error processing signature:', error);
      }
    }

    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            text: "OPERATION DUDULA MEMBERSHIP APPLICATION",
            heading: HeadingLevel.TITLE,
            alignment: "center",
          }),
          new Paragraph({
            text: "",
            spacing: { after: 200 }
          }),
            new Paragraph({
              children: [
                new TextRun({ text: "Card Number: ", bold: true }),
                new TextRun(getField('cardNumber', 'card_number') || getField('operation_dudula_card_number') || 'Not assigned')
              ]
            }),
          new Paragraph({
            children: [
              new TextRun({ text: "Status: ", bold: true }),
              new TextRun(application.activated ? "ACTIVATED" : "PENDING")
            ]
          }),
          new Paragraph({
            text: "",
            spacing: { after: 200 }
          }),
          new Paragraph({
            text: "PERSONAL INFORMATION",
            heading: HeadingLevel.HEADING_1,
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "First Name", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('firstName', 'first_name'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Last Name", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('lastName', 'last_name'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Email", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(application.email)] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Nationality", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('nationality') || 'Not specified')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Mobile Number", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('mobileNumber', 'mobile_number'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "ID Number", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('idNumber', 'id_number'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Gender", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('gender') || 'Not specified')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Race", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('race') || 'Not specified')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Employment Status", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('employed') || 'Not specified')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Qualification", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('qualification') || 'Not specified')] })
                ]
              })
            ]
          }),
          new Paragraph({
            text: "",
            spacing: { after: 200 }
          }),
          new Paragraph({
            text: "ADDRESS INFORMATION",
            heading: HeadingLevel.HEADING_1,
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Address Line 1", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('addressLine1', 'address_line1'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Address Line 2", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('addressLine2', 'address_line2'))] })
                ]
              }),
              ...(getField('addressLine3', 'address_line3') ? [new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Address Line 3", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('addressLine3', 'address_line3'))] })
                ]
              })] : []),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Ward No", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('wardNo', 'ward_no'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Province", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('province') || 'Not specified')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Sub Region", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('subRegion', 'sub_region'))] })
                ]
              })
            ]
          }),
          new Paragraph({
            text: "",
            spacing: { after: 200 }
          }),
          new Paragraph({
            text: "MEMBERSHIP DETAILS",
            heading: HeadingLevel.HEADING_1,
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Period", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('period') || 'Not specified')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Membership Status", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('membershipStatus', 'membership_status'))] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Declaration Name", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(getField('declarationName', 'declaration_name') || '')] })
                ]
              }),
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Submitted Date", bold: true })] })] }),
                  new TableCell({ children: [new Paragraph(new Date(getField('submittedDate', 'submitted_date')).toLocaleDateString())] })
                ]
              })
            ]
          }),
          new Paragraph({
            text: "",
            spacing: { after: 200 }
          }),
          new Paragraph({
            text: "SIGNATURE",
            heading: HeadingLevel.HEADING_1,
          }),
          ...(signatureImageRun ? [
            new Paragraph({
              children: [signatureImageRun],
              alignment: "left",
            })
          ] : [
            new Paragraph({
              children: [new TextRun({ text: "Digital signature on file", italics: true })],
            })
          ])
        ]
      }]
    });

    const blob = await Packer.toBlob(doc);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${getField('firstName', 'first_name')}_${getField('lastName', 'last_name')}_Application.docx`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  if (!application) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Application Details - {getField('firstName', 'first_name')} {getField('lastName', 'last_name')}</DialogTitle>
            <Button onClick={exportToWord} variant="outline" size="sm" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Export to Word
            </Button>
          </div>
        </DialogHeader>
        
        <div className="bg-white p-8 border rounded-lg space-y-6 text-sm" style={{ minHeight: '297mm', width: '210mm', margin: '0 auto' }}>
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">OPERATION DUDULA MEMBERSHIP APPLICATION</h1>
            <div className="flex justify-between text-sm mb-4">
              <span><strong>Card Number:</strong> {getField('cardNumber', 'card_number') || getField('operation_dudula_card_number') || 'Not assigned'}</span>
              <span><strong>Status:</strong> <span className={application.activated ? 'text-green-600' : 'text-orange-600'}>{application.activated ? 'ACTIVATED' : 'PENDING'}</span></span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <h3 className="font-bold text-lg mb-3 border-b pb-1">Personal Information</h3>
              <div className="space-y-2">
                <div><strong>First Name:</strong> {getField('firstName', 'first_name')}</div>
                <div><strong>Last Name:</strong> {getField('lastName', 'last_name')}</div>
                <div><strong>Email:</strong> {application.email}</div>
                <div><strong>Nationality:</strong> {getField('nationality') || 'Not specified'}</div>
                <div><strong>Mobile Number:</strong> {getField('mobileNumber', 'mobile_number')}</div>
                {getField('alternativeNumber', 'alternative_number') && <div><strong>Alternative Number:</strong> {getField('alternativeNumber', 'alternative_number')}</div>}
                <div><strong>ID Number:</strong> {getField('idNumber', 'id_number')}</div>
                <div><strong>Gender:</strong> {getField('gender') || 'Not specified'}</div>
                <div><strong>Race:</strong> {getField('race') || 'Not specified'}</div>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-3 border-b pb-1">Employment & Education</h3>
              <div className="space-y-2">
                <div><strong>Employment Status:</strong> {getField('employed') || 'Not specified'}</div>
                <div><strong>Qualification:</strong> {getField('qualification') || 'Not specified'}</div>
              </div>

              <h3 className="font-bold text-lg mb-3 mt-6 border-b pb-1">Membership Details</h3>
              <div className="space-y-2">
                <div><strong>Period:</strong> {getField('period') || 'Not specified'}</div>
                <div><strong>Membership Status:</strong> {getField('membershipStatus', 'membership_status')}</div>
                {getField('declarationName', 'declaration_name') && <div><strong>Declaration Name:</strong> {getField('declarationName', 'declaration_name')}</div>}
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-3 border-b pb-1">Address Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div><strong>Address Line 1:</strong> {getField('addressLine1', 'address_line1')}</div>
              <div><strong>Address Line 2:</strong> {getField('addressLine2', 'address_line2')}</div>
              {getField('addressLine3', 'address_line3') && <div><strong>Address Line 3:</strong> {getField('addressLine3', 'address_line3')}</div>}
              <div><strong>Ward No:</strong> {getField('wardNo', 'ward_no')}</div>
              <div><strong>Province:</strong> {getField('province') || 'Not specified'}</div>
              <div><strong>Sub Region:</strong> {getField('subRegion', 'sub_region')}</div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t">
            <div className="flex justify-between items-center">
              <div><strong>Submitted Date:</strong> {new Date(getField('submittedDate', 'submitted_date')).toLocaleDateString()}</div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground mb-2">Signature:</div>
                {application.signature && (
                  <img 
                    src={application.signature} 
                    alt="Digital Signature" 
                    className="max-w-32 max-h-16 object-contain border rounded"
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
