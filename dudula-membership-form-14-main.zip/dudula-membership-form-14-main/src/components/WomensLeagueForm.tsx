import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import SignatureCanvas from 'react-signature-canvas';

interface WomensLeagueFormData {
  operationDudulaCardNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  idNumber: string;
  signature: string;
}

export const WomensLeagueForm = () => {
  const [formData, setFormData] = useState<WomensLeagueFormData>({
    operationDudulaCardNumber: '',
    firstName: '',
    lastName: '',
    email: '',
    idNumber: '',
    signature: ''
  });
  const [signatureRef, setSignatureRef] = useState<SignatureCanvas | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEligible, setIsEligible] = useState<boolean | null>(null);
  const [checkingEligibility, setCheckingEligibility] = useState(false);
  const { toast } = useToast();

  const checkEligibility = async () => {
    if (!formData.operationDudulaCardNumber) {
      toast({
        title: "Card Number Required",
        description: "Please enter your Operation Dudula card number to check eligibility.",
        variant: "destructive"
      });
      return;
    }

    setCheckingEligibility(true);
    try {
      const { data, error } = await supabase
        .from('applications')
        .select('id, activated')
        .eq('card_number', formData.operationDudulaCardNumber)
        .eq('activated', true)
        .single();

      if (error || !data) {
        setIsEligible(false);
        toast({
          title: "Not Eligible",
          description: "You must have an activated Operation Dudula membership to apply for Women's League membership.",
          variant: "destructive"
        });
      } else {
        setIsEligible(true);
        toast({
          title: "Eligible!",
          description: "You are eligible to apply for Women's League membership.",
        });
      }
    } catch (error) {
      console.error('Error checking eligibility:', error);
      toast({
        title: "Error",
        description: "Failed to check eligibility. Please try again.",
        variant: "destructive"
      });
    } finally {
      setCheckingEligibility(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (name === 'operationDudulaCardNumber') {
      setIsEligible(null);
    }
  };

  const clearSignature = () => {
    if (signatureRef) {
      signatureRef.clear();
    }
  };

  const saveSignature = () => {
    if (signatureRef) {
      const signatureData = signatureRef.toDataURL();
      setFormData(prev => ({ ...prev, signature: signatureData }));
      toast({
        title: "Signature Saved",
        description: "Your signature has been captured successfully.",
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isEligible) {
      toast({
        title: "Eligibility Required",
        description: "Please check your eligibility first before submitting the application.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.signature) {
      toast({
        title: "Signature Required",
        description: "Please provide your signature before submitting.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const membershipData = {
        operation_dudula_card_number: formData.operationDudulaCardNumber,
        first_name: formData.firstName,
        last_name: formData.lastName,
        email: formData.email,
        id_number: formData.idNumber,
        signature: formData.signature,
        membership_status: 'pending',
        activated: false
      };

      const { error } = await supabase
        .from('womens_league_memberships')
        .insert([membershipData]);

      if (error) {
        throw error;
      }

      toast({
        title: "Application Submitted!",
        description: "Your Women's League membership application has been submitted successfully. You will receive an email confirmation shortly.",
      });

      // Reset form
      setFormData({
        operationDudulaCardNumber: '',
        firstName: '',
        lastName: '',
        email: '',
        idNumber: '',
        signature: ''
      });
      if (signatureRef) {
        signatureRef.clear();
      }
      setIsEligible(null);
      
    } catch (error: any) {
      console.error('Error submitting application:', error);
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Women's League Membership Application</CardTitle>
          <p className="text-center text-muted-foreground">
            Apply for Women's League membership. You must have an activated Operation Dudula membership to be eligible.
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  name="operationDudulaCardNumber"
                  placeholder="Operation Dudula Card Number"
                  value={formData.operationDudulaCardNumber}
                  onChange={handleInputChange}
                  required
                  className="flex-1"
                />
                <Button 
                  type="button" 
                  onClick={checkEligibility}
                  disabled={checkingEligibility || !formData.operationDudulaCardNumber}
                  variant="outline"
                >
                  {checkingEligibility ? 'Checking...' : 'Check Eligibility'}
                </Button>
              </div>
              
              {isEligible === false && (
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                  <p className="text-destructive text-sm">
                    You must have an activated Operation Dudula membership to apply for Women's League membership.
                  </p>
                </div>
              )}
              
              {isEligible === true && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                  <p className="text-green-700 text-sm">
                    ✓ You are eligible to apply for Women's League membership!
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  name="firstName"
                  placeholder="First Name"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  required
                  disabled={!isEligible}
                />
                <Input
                  name="lastName"
                  placeholder="Last Name"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  required
                  disabled={!isEligible}
                />
              </div>

              <Input
                name="email"
                type="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleInputChange}
                required
                disabled={!isEligible}
              />

              <Input
                name="idNumber"
                placeholder="ID Number"
                value={formData.idNumber}
                onChange={handleInputChange}
                required
                disabled={!isEligible}
              />

              <div className="space-y-2">
                <label className="text-sm font-medium">Digital Signature</label>
                <div className={`border border-gray-300 rounded-md p-2 ${!isEligible ? 'opacity-50 pointer-events-none' : ''}`}>
                  <SignatureCanvas
                    ref={setSignatureRef}
                    canvasProps={{
                      width: 500,
                      height: 200,
                      className: 'signature-canvas w-full border rounded'
                    }}
                  />
                </div>
                <div className="flex gap-2">
                  <Button type="button" onClick={clearSignature} variant="outline" size="sm" disabled={!isEligible}>
                    Clear Signature
                  </Button>
                  <Button type="button" onClick={saveSignature} variant="outline" size="sm" disabled={!isEligible}>
                    Save Signature
                  </Button>
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting || !isEligible}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Application'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};