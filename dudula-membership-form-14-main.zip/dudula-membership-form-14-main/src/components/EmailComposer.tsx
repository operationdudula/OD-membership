import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Mail } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface EmailComposerProps {
  isOpen: boolean;
  onClose: () => void;
  application: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    cardNumber: string;
  };
  onSendEmail: (application: any, emailData: any) => void;
}

export function EmailComposer({ isOpen, onClose, application, onSendEmail }: EmailComposerProps) {
  const [subject, setSubject] = useState(`Welcome to Operation Dudula - ${application.firstName || 'Member'} ${application.lastName || ''}`);
  const [message, setMessage] = useState(`Dear Member ${application.firstName || ''} ${application.lastName || ''},

Welcome to Operation Dudula!

We are pleased to inform you that your membership application has been approved and activated.

Your unique membership card number is: ${application.cardNumber || `OD${Date.now()}`}

Thank you for joining our organization and becoming part of our mission. We look forward to your active participation in Operation Dudula.

Best regards,
Operation Dudula Admin Team`);
  const [organizationLogo, setOrganizationLogo] = useState<string>('');
  
  const { toast } = useToast();

  useEffect(() => {
    // Load organization logo from localStorage
    const savedLogo = localStorage.getItem('dudula-organization-logo');
    if (savedLogo) {
      setOrganizationLogo(savedLogo);
    }
  }, []);

  const handleSend = () => {
    onSendEmail(application, { subject, message });
    toast({
      title: "Email Sent",
      description: `Activation email sent to ${application.email}`,
    });
    onClose();
    setSubject(`Welcome to Operation Dudula - ${application.firstName || 'Member'} ${application.lastName || ''}`);
    setMessage(`Dear Member ${application.firstName || ''} ${application.lastName || ''},

Welcome to Operation Dudula!

We are pleased to inform you that your membership application has been approved and activated.

Your unique membership card number is: ${application.cardNumber || `OD${Date.now()}`}

Thank you for joining our organization and becoming part of our mission. We look forward to your active participation in Operation Dudula.

Best regards,
Operation Dudula Admin Team`);
  };

  const openGmail = async () => {
    let emailBody = message;
    if (organizationLogo) {
      emailBody += `\n\n[Organization Logo will appear here when sent from Gmail]`;
    }
    const encodedBody = encodeURIComponent(emailBody);
    const emailSubject = encodeURIComponent(subject);
    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${application.email}&su=${emailSubject}&body=${encodedBody}`;
    window.open(gmailUrl, '_blank');
    
    // Update application status to verified and activated in Supabase
    try {
      const { error } = await supabase
        .from('applications')
        .update({ 
          membership_status: 'verified',
          activated: true
        })
        .eq('id', application.id);
      
      if (error) {
        console.error('Failed to update application status:', error);
      }
    } catch (error) {
      console.error('Error updating application status:', error);
    }
    
    // Activate the application after opening Gmail
    onSendEmail(application, { subject, message });
    toast({
      title: "Gmail Opened",
      description: `Email template opened in Gmail and application verified`,
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Send Activation Email</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="recipient">Recipient</Label>
            <Input
              id="recipient"
              value={`${application.firstName} ${application.lastName} <${application.email}>`}
              readOnly
              className="bg-muted"
            />
          </div>
          
          <div>
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>
          
          <div>
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={8}
              className="resize-none"
            />
          </div>
          
          {organizationLogo && (
            <div>
              <Label>Organization Logo Preview</Label>
              <div className="mt-2 p-4 border rounded-lg bg-muted/50">
                <img 
                  src={organizationLogo} 
                  alt="Organization Logo" 
                  className="max-w-32 max-h-16 object-contain mx-auto"
                />
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  This logo will appear in the email signature
                </p>
              </div>
            </div>
          )}
          
          <div className="bg-muted/50 p-3 rounded-lg">
            <h4 className="font-semibold mb-2 text-sm">Email Preview:</h4>
            <div className="text-xs space-y-1">
              <p><strong>To:</strong> {application.email}</p>
              <p><strong>Subject:</strong> {subject}</p>
              <div className="bg-white p-2 rounded border max-h-32 overflow-y-auto">
                <pre className="whitespace-pre-wrap text-xs">{message}</pre>
                {organizationLogo && (
                  <div className="mt-2 pt-2 border-t">
                    <img 
                      src={organizationLogo} 
                      alt="Organization Logo" 
                      className="max-w-24 max-h-12 object-contain"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={openGmail} className="flex items-center gap-2 bg-success hover:bg-success/90">
              <Mail className="h-4 w-4" />
              Send to Gmail
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}