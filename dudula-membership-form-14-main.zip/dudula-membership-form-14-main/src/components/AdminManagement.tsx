import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Trash2, Users, Plus } from 'lucide-react';

interface Admin {
  id: string;
  username: string;
  password: string;
  createdDate: string;
}

export function AdminManagement() {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [newAdminUsername, setNewAdminUsername] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Load admins from localStorage
    const savedAdmins = localStorage.getItem('dudula-admins');
    if (savedAdmins) {
      setAdmins(JSON.parse(savedAdmins));
    } else {
      // Set default admins
      const defaultAdmins = [
        {
          id: '1',
          username: 'admin',
          password: 'password',
          createdDate: new Date().toISOString()
        },
        {
          id: '2',
          username: 'khangwelo',
          password: 'khangwelo',
          createdDate: new Date().toISOString()
        },
        {
          id: '3',
          username: 'operationdudula123',
          password: 'Operationdudula@123',
          createdDate: new Date().toISOString()
        },
        {
          id: '4',
          username: 'Zandile Dabula',
          password: 'Zandiledabula@123',
          createdDate: new Date().toISOString()
        },
        {
          id: '5',
          username: 'khangwi',
          password: 'khangwi',
          createdDate: new Date().toISOString()
        }
      ];
      setAdmins(defaultAdmins);
      localStorage.setItem('dudula-admins', JSON.stringify(defaultAdmins));
    }
  }, []);

  const createNewAdmin = () => {
    if (newAdminUsername && newAdminPassword) {
      // Check if username already exists
      if (admins.some(admin => admin.username === newAdminUsername)) {
        toast({
          title: "Error",
          description: "Username already exists",
          variant: "destructive",
        });
        return;
      }

      const newAdmin: Admin = {
        id: Date.now().toString(),
        username: newAdminUsername,
        password: newAdminPassword,
        createdDate: new Date().toISOString()
      };

      const updatedAdmins = [...admins, newAdmin];
      setAdmins(updatedAdmins);
      localStorage.setItem('dudula-admins', JSON.stringify(updatedAdmins));

      toast({
        title: "Admin Created",
        description: `New admin ${newAdminUsername} has been created`,
      });
      
      setNewAdminUsername('');
      setNewAdminPassword('');
      setIsDialogOpen(false);
    }
  };

  const deleteAdmin = (adminId: string) => {
    if (admins.length === 1) {
      toast({
        title: "Error",
        description: "Cannot delete the last admin",
        variant: "destructive",
      });
      return;
    }

    const updatedAdmins = admins.filter(admin => admin.id !== adminId);
    setAdmins(updatedAdmins);
    localStorage.setItem('dudula-admins', JSON.stringify(updatedAdmins));

    toast({
      title: "Admin Deleted",
      description: "Admin has been removed",
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Admin Management
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Admin
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Admin</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="newUsername">Username</Label>
                  <Input
                    id="newUsername"
                    value={newAdminUsername}
                    onChange={(e) => setNewAdminUsername(e.target.value)}
                    placeholder="Enter username"
                  />
                </div>
                <div>
                  <Label htmlFor="newPassword">Password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                    placeholder="Enter password"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createNewAdmin}>
                    Create Admin
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {admins.map((admin) => (
            <div key={admin.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex-1">
                <div className="font-medium">{admin.username}</div>
                <div className="text-sm text-muted-foreground">
                  Password: {admin.password}
                </div>
                <div className="text-xs text-muted-foreground">
                  Created: {new Date(admin.createdDate).toLocaleDateString()}
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => deleteAdmin(admin.id)}
                className="text-destructive hover:text-destructive"
                disabled={admins.length === 1}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}