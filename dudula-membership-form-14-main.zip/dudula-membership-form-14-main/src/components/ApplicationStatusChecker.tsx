import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { X } from 'lucide-react';

interface ApplicationStatusCheckerProps {
  isOpen: boolean;
  onClose: () => void;
}

const ApplicationStatusChecker = ({ isOpen, onClose }: ApplicationStatusCheckerProps) => {
  const [searchData, setSearchData] = useState({
    email: '',
    idNumber: '',
    phoneNumber: ''
  });
  const [applicationStatus, setApplicationStatus] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!searchData.email && !searchData.idNumber && !searchData.phoneNumber) {
      toast({
        title: "Error",
        description: "Please provide at least one search criteria (email, ID number, or phone number).",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    try {
      // Search in applications table
      let query = supabase.from('applications').select('*');
      
      if (searchData.email) {
        query = query.eq('email', searchData.email);
      } else if (searchData.idNumber) {
        query = query.eq('id_number', searchData.idNumber);
      } else if (searchData.phoneNumber) {
        query = query.eq('mobile_number', searchData.phoneNumber);
      }

      const { data: applicationData, error: applicationError } = await query.single();

      if (applicationData) {
        setApplicationStatus({
          type: 'application',
          data: applicationData
        });
        return;
      }

      // Search in mens_league_memberships
      let mensQuery = supabase.from('mens_league_memberships').select('*');
      if (searchData.email) {
        mensQuery = mensQuery.eq('email', searchData.email);
      } else if (searchData.idNumber) {
        mensQuery = mensQuery.eq('id_number', searchData.idNumber);
      }

      const { data: mensData } = await mensQuery.single();
      if (mensData) {
        setApplicationStatus({
          type: 'mens_league',
          data: mensData
        });
        return;
      }

      // Search in womens_league_memberships
      let womensQuery = supabase.from('womens_league_memberships').select('*');
      if (searchData.email) {
        womensQuery = womensQuery.eq('email', searchData.email);
      } else if (searchData.idNumber) {
        womensQuery = womensQuery.eq('id_number', searchData.idNumber);
      }

      const { data: womensData } = await womensQuery.single();
      if (womensData) {
        setApplicationStatus({
          type: 'womens_league',
          data: womensData
        });
        return;
      }

      // Search in youth_league_memberships
      let youthQuery = supabase.from('youth_league_memberships').select('*');
      if (searchData.email) {
        youthQuery = youthQuery.eq('email', searchData.email);
      } else if (searchData.idNumber) {
        youthQuery = youthQuery.eq('id_number', searchData.idNumber);
      }

      const { data: youthData } = await youthQuery.single();
      if (youthData) {
        setApplicationStatus({
          type: 'youth_league',
          data: youthData
        });
        return;
      }

      // No application found
      setApplicationStatus(null);
      toast({
        title: "No Application Found",
        description: "No application found with the provided search criteria.",
        variant: "destructive",
      });

    } catch (error) {
      console.error('Error searching application:', error);
      setApplicationStatus(null);
      toast({
        title: "No Application Found",
        description: "No application found with the provided search criteria.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Check Application Status</CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <CardDescription>
            Enter your details to check your application status
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={searchData.email}
              onChange={handleInputChange}
              placeholder="Enter your email"
            />
          </div>

          <div>
            <Label htmlFor="idNumber">ID Number</Label>
            <Input
              id="idNumber"
              name="idNumber"
              value={searchData.idNumber}
              onChange={handleInputChange}
              placeholder="Enter your ID number"
            />
          </div>

          <div>
            <Label htmlFor="phoneNumber">Phone Number</Label>
            <Input
              id="phoneNumber"
              name="phoneNumber"
              value={searchData.phoneNumber}
              onChange={handleInputChange}
              placeholder="Enter your phone number"
            />
          </div>

          {applicationStatus && (
            <div className="mt-4 p-4 bg-primary/5 rounded-lg">
              <h3 className="font-semibold text-primary mb-2">Application Found</h3>
              <div className="space-y-1 text-sm">
                <p><span className="font-medium">Name:</span> {applicationStatus.data.first_name} {applicationStatus.data.last_name}</p>
                <p><span className="font-medium">Email:</span> {applicationStatus.data.email}</p>
                <p><span className="font-medium">ID Number:</span> {applicationStatus.data.id_number}</p>
                {applicationStatus.data.operation_dudula_card_number && (
                  <p><span className="font-medium">Card Number:</span> {applicationStatus.data.operation_dudula_card_number}</p>
                )}
                <p><span className="font-medium">Status:</span> 
                  <span className={`ml-1 px-2 py-1 rounded text-xs ${
                    applicationStatus.data.membership_status === 'verified' ? 'bg-green-100 text-green-800' :
                    applicationStatus.data.membership_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {applicationStatus.data.membership_status}
                  </span>
                </p>
                <p><span className="font-medium">Submitted:</span> {new Date(applicationStatus.data.submitted_date).toLocaleDateString()}</p>
                <p><span className="font-medium">Activated:</span> {applicationStatus.data.activated ? 'Yes' : 'No'}</p>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="flex-1"
            >
              Close
            </Button>
            <Button 
              onClick={handleSearch}
              disabled={isSearching}
              className="flex-1"
            >
              {isSearching ? 'Searching...' : 'Check Status'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ApplicationStatusChecker;