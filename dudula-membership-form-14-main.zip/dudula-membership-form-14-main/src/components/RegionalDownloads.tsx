import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';
import { provinceRegions } from '@/utils/regionData';

interface Application {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  idNumber: string;
  mobileNumber: string;
  province: string;
  subRegion: string;
  membershipStatus: string;
  submittedDate: string;
  activated: boolean;
}

export function RegionalDownloads() {
  const [selectedProvince, setSelectedProvince] = useState('');
  const [selectedSubRegion, setSelectedSubRegion] = useState('');
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAllApplications();
  }, []);

  const loadAllApplications = async () => {
    try {
      const allApplications: Application[] = [];

      // Load from main applications table
      const { data: mainApps, error: mainError } = await supabase
        .from('applications')
        .select('*');

      if (mainApps && !mainError) {
        allApplications.push(...mainApps.map(app => ({
          id: app.id,
          firstName: app.first_name,
          lastName: app.last_name,
          email: app.email,
          idNumber: app.id_number,
          mobileNumber: app.mobile_number,
          province: app.province,
          subRegion: app.sub_region,
          membershipStatus: app.membership_status,
          submittedDate: app.submitted_date,
          activated: app.activated
        })));
      }

      setApplications(allApplications);
    } catch (error) {
      console.error('Error loading applications:', error);
      toast({
        title: "Error",
        description: "Failed to load applications",
        variant: "destructive",
      });
    }
  };

  const getSubRegions = () => {
    if (!selectedProvince) return [];
    const provinceData = provinceRegions[selectedProvince];
    if (!provinceData) return [];
    // Flatten all sub-regions from all districts
    return Object.values(provinceData).flat();
  };

  const getFilteredApplications = () => {
    let filtered = applications;

    if (selectedProvince) {
      filtered = filtered.filter(app => app.province === selectedProvince);
    }

    if (selectedSubRegion) {
      filtered = filtered.filter(app => app.subRegion === selectedSubRegion);
    }

    return filtered;
  };

  const downloadRegionalExcel = () => {
    if (!selectedProvince) {
      toast({
        title: "Selection Required",
        description: "Please select a province first",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    const filteredApps = getFilteredApplications();
    
    if (filteredApps.length === 0) {
      toast({
        title: "No Data",
        description: "No applications found for the selected region",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    const exportData = filteredApps.map(app => ({
      'ID Number': app.idNumber,
      'First Name': app.firstName,
      'Last Name': app.lastName,
      'Email': app.email,
      'Mobile Number': app.mobileNumber,
      'Province': app.province,
      'Sub Region': app.subRegion,
      'Membership Status': app.membershipStatus,
      'Activated': app.activated ? 'Yes' : 'No',
      'Submitted Date': new Date(app.submittedDate).toLocaleDateString()
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Regional Applications');
    
    const fileName = selectedSubRegion 
      ? `${selectedProvince}-${selectedSubRegion}-applications-${new Date().toISOString().split('T')[0]}.xlsx`
      : `${selectedProvince}-applications-${new Date().toISOString().split('T')[0]}.xlsx`;
    
    XLSX.writeFile(wb, fileName);
    
    toast({
      title: "Export Successful",
      description: `Downloaded ${filteredApps.length} applications for ${selectedSubRegion || selectedProvince}`,
    });
    
    setIsLoading(false);
  };

  const filteredCount = getFilteredApplications().length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5" />
          Regional Application Downloads
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Province</label>
            <Select value={selectedProvince} onValueChange={(value) => {
              setSelectedProvince(value);
              setSelectedSubRegion(''); // Reset sub-region when province changes
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Select Province" />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(provinceRegions).map((province) => (
                  <SelectItem key={province} value={province}>
                    {province}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Sub Region (Optional)</label>
            <Select 
              value={selectedSubRegion} 
              onValueChange={setSelectedSubRegion}
              disabled={!selectedProvince}
            >
              <SelectTrigger>
                <SelectValue placeholder={selectedProvince ? "Select Sub Region" : "Select Province first"} />
              </SelectTrigger>
              <SelectContent>
                {getSubRegions().map((subRegion) => (
                  <SelectItem key={subRegion} value={subRegion}>
                    {subRegion}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4">
          <div className="text-sm text-muted-foreground">
            {selectedProvince && (
              <span>
                {filteredCount} applications found in {selectedSubRegion || selectedProvince}
              </span>
            )}
          </div>
          
          <Button 
            onClick={downloadRegionalExcel}
            disabled={!selectedProvince || isLoading}
            className="flex items-center gap-2"
          >
            {isLoading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
            ) : (
              <Download className="h-4 w-4" />
            )}
            Download Excel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}