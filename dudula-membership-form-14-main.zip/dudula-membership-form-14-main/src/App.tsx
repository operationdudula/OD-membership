import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Session, User } from "@supabase/supabase-js";
import Index from "./pages/Index";
import AdminPage from "./pages/AdminPage";
import NotFound from "./pages/NotFound";
import ApplicationStatus from "./pages/ApplicationStatus";
import YouthLeaguePage from "./pages/YouthLeaguePage";
import MensLeaguePage from "./pages/MensLeaguePage";
import WomensLeaguePage from "./pages/WomensLeaguePage";
import MembershipPage from "./pages/MembershipPage";
import MensLeagueApplicationsPage from "./pages/MensLeagueApplicationsPage";
import WomensLeagueApplicationsPage from "./pages/WomensLeagueApplicationsPage";
import YouthLeagueApplicationsPage from "./pages/YouthLeagueApplicationsPage";
import ApplicationsByProvince from "./pages/ApplicationsByProvince";
import { AuthPage } from "./components/AuthPage";
import { UserProfilePage } from "./components/UserProfilePage";
import ActivatedApplicants from "./pages/ActivatedApplicants";
import VerificationPage from "./pages/VerificationPage";
import PaidApplicants from "./pages/PaidApplicants";

const queryClient = new QueryClient();

const App = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
    setSession(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<AuthPage onLogin={handleLogin} />} />
            <Route path="/" element={user ? <Index user={user} /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/profile" element={user ? <UserProfilePage user={user} onLogout={handleLogout} /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/verification" element={<VerificationPage />} />
            
            <Route path="/admin" element={user ? <AdminPage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/admin/paid-applicants" element={user ? <PaidApplicants /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/application-status" element={user ? <ApplicationStatus /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/youth-league" element={user ? <YouthLeaguePage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/mens-league" element={user ? <MensLeaguePage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/womens-league" element={user ? <WomensLeaguePage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/membership" element={user ? <MembershipPage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/mens-league-applications" element={user ? <MensLeagueApplicationsPage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/womens-league-applications" element={user ? <WomensLeagueApplicationsPage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/youth-league-applications" element={user ? <YouthLeagueApplicationsPage /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/applications-by-province" element={user ? <ApplicationsByProvince /> : <AuthPage onLogin={handleLogin} />} />
            <Route path="/activated-applicants" element={user ? <ActivatedApplicants /> : <AuthPage onLogin={handleLogin} />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
