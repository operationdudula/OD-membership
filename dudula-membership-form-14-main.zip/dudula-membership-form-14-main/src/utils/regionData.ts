
export const provinceRegions: Record<string, Record<string, string[]>> = {
  "Gauteng": {
    "City of Johannesburg Metropolitan Municipality": [
      "Region A (Diepsloot, Kya Sand)",
      "Region B (Randburg, Rosebank, Emmarentia)",
      "Region C (Roodepoort, Honeydew, Northgate)",
      "Region D (Soweto, Dobsonville, Protea Glen)",
      "Region E (Alexandra, Wynberg, Sandton)",
      "Region F (Inner City, Hillbrow, Fordsburg)",
      "Region G (Orange Farm, Lenasia, Ennerdale)"
    ],
    "City of Tshwane Metropolitan Municipality": [
      "Region 1 (Pretoria Central)",
      "Region 2 (Bronkhorstspruit)",
      "Region 3 (Centurion)",
      "Region 4 (Akasia, Rosslyn)",
      "Region 5 (Soshanguve, Mabopane)",
      "Region 6 (Mamelodi, Cullinan)",
      "Region 7 (Atteridgeville, Laudium)"
    ],
    "Ekurhuleni Metropolitan Municipality": [
      "Alberton",
      "Benoni",
      "Boksburg",
      "Brakpan",
      "Edenvale",
      "Germiston",
      "Kempton Park",
      "Nigel",
      "Springs"
    ],
    "Sedibeng District Municipality": [
      "Emfuleni Local Municipality",
      "Midvaal Local Municipality",
      "Lesedi Local Municipality"
    ],
    "West Rand District Municipality": [
      "Mogale City Local Municipality",
      "Rand West City Local Municipality"
    ]
  },
  "Western Cape": {
    "City of Cape Town Metropolitan Municipality": [
      "Blaauwberg",
      "Cape Town",
      "Goodwood",
      "Helderberg",
      "Khayelitsha",
      "Kraaifontein",
      "Mitchells Plain",
      "Northern Suburbs",
      "Oostenberg",
      "South Peninsula",
      "Tygerberg",
      "West Coast"
    ],
    "Cape Winelands District Municipality": [
      "Drakenstein Local Municipality",
      "Stellenbosch Local Municipality",
      "Breede Valley Local Municipality",
      "Langeberg Local Municipality"
    ],
    "Central Karoo District Municipality": [
      "Laingsburg Local Municipality",
      "Prince Albert Local Municipality",
      "Beaufort West Local Municipality"
    ],
    "Garden Route District Municipality": [
      "Mossel Bay Local Municipality",
      "George Local Municipality",
      "Knysna Local Municipality",
      "Bitou Local Municipality",
      "Hessequa Local Municipality",
      "Kannaland Local Municipality"
    ],
    "Overberg District Municipality": [
      "Theewaterskloof Local Municipality",
      "Overstrand Local Municipality",
      "Cape Agulhas Local Municipality",
      "Swellendam Local Municipality"
    ],
    "West Coast District Municipality": [
      "Matzikama Local Municipality",
      "Cederberg Local Municipality",
      "Bergrivier Local Municipality",
      "Saldanha Bay Local Municipality",
      "Swartland Local Municipality"
    ]
  },
  "Eastern Cape": {
    "Buffalo City Metropolitan Municipality": [
      "King Williams Town",
      "East London",
      "Mdantsane",
      "Zwelitsha",
      "Bhisho",
      "Ginsberg",
      "Duncan Village"
    ],
    "Nelson Mandela Bay Metropolitan Municipality": [
      "Port Elizabeth Central",
      "Port Elizabeth North",
      "Port Elizabeth South",
      "Uitenhage",
      "Despatch",
      "Kirkwood",
      "Blue Horizon Bay"
    ],
    "Alfred Nzo District Municipality": [
      "Matatiele Local Municipality",
      "Mbizana Local Municipality",
      "Ntabankulu Local Municipality"
    ],
    "Amathole District Municipality": [
      "Mnquma Local Municipality",
      "Mbhashe Local Municipality",
      "Ngqushwa Local Municipality",
      "Amahlathi Local Municipality"
    ],
    "Chris Hani District Municipality": [
      "Inxuba Yethemba Local Municipality",
      "Enoch Mgijima Local Municipality",
      "Intsika Yethu Local Municipality",
      "Engcobo Local Municipality",
      "Sakhisizwe Local Municipality"
    ],
    "Joe Gqabi District Municipality": [
      "Elundini Local Municipality",
      "Senqu Local Municipality",
      "Walter Sisulu Local Municipality"
    ],
    "OR Tambo District Municipality": [
      "Ingquza Hill Local Municipality",
      "Port St Johns Local Municipality",
      "Nyandeni Local Municipality",
      "Mhlontlo Local Municipality",
      "King Sabata Dalindyebo Local Municipality"
    ],
    "Sarah Baartman District Municipality": [
      "Dr Beyers Naudé Local Municipality",
      "Blue Crane Route Local Municipality",
      "Makana Local Municipality",
      "Ndlambe Local Municipality",
      "Sundays River Valley Local Municipality"
    ]
  },
  "Northern Cape": {
    "Frances Baard District Municipality": [
      "Sol Plaatje Local Municipality",
      "Dikgatlong Local Municipality",
      "Magareng Local Municipality",
      "Phokwane Local Municipality"
    ],
    "John Taolo Gaetsewe District Municipality": [
      "Joe Morolong Local Municipality",
      "Ga-Segonyana Local Municipality",
      "Gamagara Local Municipality"
    ],
    "Namakwa District Municipality": [
      "Richtersveld Local Municipality",
      "Nama Khoi Local Municipality",
      "Hantam Local Municipality",
      "Karoo Hoogland Local Municipality",
      "Khâi-Ma Local Municipality"
    ],
    "Pixley ka Seme District Municipality": [
      "Ubuntu Local Municipality",
      "Umsobomvu Local Municipality",
      "Emthanjeni Local Municipality",
      "Kareeberg Local Municipality",
      "Renosterberg Local Municipality",
      "Thembelihle Local Municipality",
      "Siyathemba Local Municipality",
      "Siyancuma Local Municipality"
    ],
    "ZF Mgcawu District Municipality": [
      "Dawid Kruiper Local Municipality",
      "Kai !Garib Local Municipality",
      "!Kheis Local Municipality",
      "Kgatelopele Local Municipality",
      "Tsantsabane Local Municipality"
    ]
  },
  "Free State": {
    "Mangaung Metropolitan Municipality": [
      "Bloemfontein",
      "Botshabelo",
      "Thaba Nchu",
      "Dewetsdorp"
    ],
    "Fezile Dabi District Municipality": [
      "Moqhaka Local Municipality",
      "Ngwathe Local Municipality",
      "Metsimaholo Local Municipality",
      "Mafube Local Municipality"
    ],
    "Lejweleputswa District Municipality": [
      "Masilonyana Local Municipality",
      "Tokologo Local Municipality",
      "Tswelopele Local Municipality",
      "Matjhabeng Local Municipality",
      "Nala Local Municipality"
    ],
    "Thabo Mofutsanyana District Municipality": [
      "Setsoto Local Municipality",
      "Dihlabeng Local Municipality",
      "Nketoana Local Municipality",
      "Maluti-a-Phofung Local Municipality",
      "Phumelela Local Municipality"
    ],
    "Xhariep District Municipality": [
      "Kopanong Local Municipality",
      "Letsemeng Local Municipality",
      "Mohokare Local Municipality"
    ]
  },
  "KwaZulu-Natal": {
    "eThekwini Metropolitan Municipality": [
      "Durban Central",
      "Durban North",
      "Durban South",
      "Pinetown",
      "Chatsworth",
      "Umlazi",
      "Phoenix",
      "Inanda",
      "KwaMashu",
      "Cato Ridge"
    ],
    "Amajuba District Municipality": [
      "Newcastle Local Municipality",
      "eMadlangeni Local Municipality",
      "Dannhauser Local Municipality"
    ],
    "Harry Gwala District Municipality": [
      "Dr Nkosazana Dlamini-Zuma Local Municipality",
      "Greater Kokstad Local Municipality",
      "Ubuhlebezwe Local Municipality",
      "Umzimkhulu Local Municipality"
    ],
    "iLembe District Municipality": [
      "Mandeni Local Municipality",
      "KwaDukuza Local Municipality",
      "Ndwedwe Local Municipality",
      "Maphumulo Local Municipality"
    ],
    "King Cetshwayo District Municipality": [
      "uMhlathuze Local Municipality",
      "Mthonjaneni Local Municipality",
      "Nkandla Local Municipality",
      "uMfolozi Local Municipality"
    ],
    "Ugu District Municipality": [
      "Ray Nkonyeni Local Municipality",
      "uMuziwabantu Local Municipality",
      "uMdoni Local Municipality",
      "Umzumbe Local Municipality"
    ],
    "uMgungundlovu District Municipality": [
      "Mooi-Mpofana Local Municipality",
      "uMngeni Local Municipality",
      "Mpofana Local Municipality",
      "Msunduzi Local Municipality",
      "Mkhambathini Local Municipality",
      "Richmond Local Municipality"
    ],
    "uMkhanyakude District Municipality": [
      "Umhlabuyalingana Local Municipality",
      "Jozini Local Municipality",
      "Big Five Hlabisa Local Municipality",
      "Mtubatuba Local Municipality"
    ],
    "uThukela District Municipality": [
      "Alfred Duma Local Municipality",
      "Inkosi Langalibalele Local Municipality",
      "Okhahlamba Local Municipality"
    ],
    "Zululand District Municipality": [
      "Ulundi Local Municipality",
      "Nongoma Local Municipality",
      "AbaQulusi Local Municipality",
      "uPhongolo Local Municipality",
      "eDumbe Local Municipality"
    ]
  },
  "Mpumalanga": {
    "Ehlanzeni District Municipality": [
      "Thaba Chweu Local Municipality",
      "Mbombela Local Municipality",
      "Umjindi Local Municipality",
      "Bushbuckridge Local Municipality",
      "Nkomazi Local Municipality"
    ],
    "Gert Sibande District Municipality": [
      "Albert Luthuli Local Municipality",
      "Msukaligwa Local Municipality",
      "Mkhondo Local Municipality",
      "Lekwa Local Municipality",
      "Govan Mbeki Local Municipality",
      "Dr Pixley Ka Isaka Seme Local Municipality"
    ],
    "Nkangala District Municipality": [
      "Steve Tshwete Local Municipality",
      "Delmas Local Municipality",
      "Emakhazeni Local Municipality",
      "Thembisile Hani Local Municipality",
      "Dr JS Moroka Local Municipality"
    ]
  },
  "North West": {
    "Bojanala Platinum District Municipality": [
      "Moretele Local Municipality",
      "Madibeng Local Municipality",
      "Rustenburg Local Municipality",
      "Kgetlengrivier Local Municipality",
      "Moses Kotane Local Municipality"
    ],
    "Dr Kenneth Kaunda District Municipality": [
      "JB Marks Local Municipality",
      "Maquassi Hills Local Municipality",
      "Matlosana Local Municipality"
    ],
    "Dr Ruth Segomotsi Mompati District Municipality": [
      "Naledi Local Municipality",
      "Mamusa Local Municipality",
      "Greater Taung Local Municipality",
      "Lekwa-Teemane Local Municipality",
      "Kagisano-Molopo Local Municipality"
    ],
    "Ngaka Modiri Molema District Municipality": [
      "Ratlou Local Municipality",
      "Tswaing Local Municipality",
      "Mahikeng Local Municipality",
      "Ditsobotla Local Municipality",
      "Ramotshere Moiloa Local Municipality"
    ]
  },
  "Limpopo": {
    "Capricorn District Municipality": [
      "Polokwane Local Municipality",
      "Blouberg Local Municipality",
      "Molemole Local Municipality",
      "Lepelle-Nkumpi Local Municipality"
    ],
    "Mopani District Municipality": [
      "Greater Giyani Local Municipality",
      "Greater Letaba Local Municipality",
      "Greater Tzaneen Local Municipality",
      "Maruleng Local Municipality",
      "Ba-Phalaborwa Local Municipality"
    ],
    "Sekhukhune District Municipality": [
      "Elias Motsoaledi Local Municipality",
      "Makhuduthamaga Local Municipality",
      "Tubatse-Fetakgomo Local Municipality",
      "Ephraim Mogale Local Municipality"
    ],
    "Vhembe District Municipality": [
      "Thulamela Local Municipality",
      "Makhado Local Municipality",
      "Mutale Local Municipality",
      "Musina Local Municipality"
    ],
    "Waterberg District Municipality": [
      "Bela-Bela Local Municipality",
      "Lephalale Local Municipality",
      "Modimolle-Mookgophong Local Municipality",
      "Mogalakwena Local Municipality",
      "Thabazimbi Local Municipality"
    ]
  }
};
