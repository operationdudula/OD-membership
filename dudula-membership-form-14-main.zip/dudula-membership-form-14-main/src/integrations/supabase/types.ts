export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      applications: {
        Row: {
          activated: boolean
          address_line1: string
          address_line2: string
          address_line3: string | null
          alternative_number: string | null
          card_number: string | null
          created_at: string
          declaration_name: string | null
          email: string
          employed: string
          first_name: string
          gender: string
          id: string
          id_number: string
          last_name: string
          membership_status: string
          mobile_number: string
          nationality: string
          period: string
          province: string
          qualification: string
          race: string
          signature: string
          sub_region: string
          submitted_date: string
          updated_at: string
          ward_no: string
        }
        Insert: {
          activated?: boolean
          address_line1: string
          address_line2: string
          address_line3?: string | null
          alternative_number?: string | null
          card_number?: string | null
          created_at?: string
          declaration_name?: string | null
          email: string
          employed: string
          first_name: string
          gender: string
          id?: string
          id_number: string
          last_name: string
          membership_status?: string
          mobile_number: string
          nationality: string
          period: string
          province: string
          qualification: string
          race: string
          signature: string
          sub_region: string
          submitted_date?: string
          updated_at?: string
          ward_no: string
        }
        Update: {
          activated?: boolean
          address_line1?: string
          address_line2?: string
          address_line3?: string | null
          alternative_number?: string | null
          card_number?: string | null
          created_at?: string
          declaration_name?: string | null
          email?: string
          employed?: string
          first_name?: string
          gender?: string
          id?: string
          id_number?: string
          last_name?: string
          membership_status?: string
          mobile_number?: string
          nationality?: string
          period?: string
          province?: string
          qualification?: string
          race?: string
          signature?: string
          sub_region?: string
          submitted_date?: string
          updated_at?: string
          ward_no?: string
        }
        Relationships: []
      }
      mens_league_memberships: {
        Row: {
          activated: boolean
          created_at: string
          email: string
          expires_at: string
          first_name: string
          id: string
          id_number: string
          last_name: string
          membership_status: string
          operation_dudula_card_number: string | null
          signature: string
          submitted_date: string
          updated_at: string
        }
        Insert: {
          activated?: boolean
          created_at?: string
          email: string
          expires_at?: string
          first_name: string
          id?: string
          id_number: string
          last_name: string
          membership_status?: string
          operation_dudula_card_number?: string | null
          signature: string
          submitted_date?: string
          updated_at?: string
        }
        Update: {
          activated?: boolean
          created_at?: string
          email?: string
          expires_at?: string
          first_name?: string
          id?: string
          id_number?: string
          last_name?: string
          membership_status?: string
          operation_dudula_card_number?: string | null
          signature?: string
          submitted_date?: string
          updated_at?: string
        }
        Relationships: []
      }
      paid_applicants: {
        Row: {
          created_at: string
          email: string
          first_name: string
          id: string
          id_number: string
          last_name: string
          phone_number: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          first_name: string
          id?: string
          id_number: string
          last_name: string
          phone_number: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          first_name?: string
          id?: string
          id_number?: string
          last_name?: string
          phone_number?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          first_name: string | null
          id: string
          last_name: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          first_name?: string | null
          id?: string
          last_name?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          first_name?: string | null
          id?: string
          last_name?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      womens_league_memberships: {
        Row: {
          activated: boolean
          created_at: string
          email: string
          expires_at: string
          first_name: string
          id: string
          id_number: string
          last_name: string
          membership_status: string
          operation_dudula_card_number: string | null
          signature: string
          submitted_date: string
          updated_at: string
        }
        Insert: {
          activated?: boolean
          created_at?: string
          email: string
          expires_at?: string
          first_name: string
          id?: string
          id_number: string
          last_name: string
          membership_status?: string
          operation_dudula_card_number?: string | null
          signature: string
          submitted_date?: string
          updated_at?: string
        }
        Update: {
          activated?: boolean
          created_at?: string
          email?: string
          expires_at?: string
          first_name?: string
          id?: string
          id_number?: string
          last_name?: string
          membership_status?: string
          operation_dudula_card_number?: string | null
          signature?: string
          submitted_date?: string
          updated_at?: string
        }
        Relationships: []
      }
      youth_league_memberships: {
        Row: {
          activated: boolean
          created_at: string
          email: string
          expires_at: string
          first_name: string
          id: string
          id_number: string
          last_name: string
          membership_status: string
          operation_dudula_card_number: string | null
          signature: string
          submitted_date: string
          updated_at: string
        }
        Insert: {
          activated?: boolean
          created_at?: string
          email: string
          expires_at?: string
          first_name: string
          id?: string
          id_number: string
          last_name: string
          membership_status?: string
          operation_dudula_card_number?: string | null
          signature: string
          submitted_date?: string
          updated_at?: string
        }
        Update: {
          activated?: boolean
          created_at?: string
          email?: string
          expires_at?: string
          first_name?: string
          id?: string
          id_number?: string
          last_name?: string
          membership_status?: string
          operation_dudula_card_number?: string | null
          signature?: string
          submitted_date?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
