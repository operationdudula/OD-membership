
import React, { useState, useEffect } from 'react';
import { MembershipForm } from '@/components/MembershipForm';
import { SuccessMessage } from '@/components/SuccessMessage';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { User } from 'lucide-react';
import ApplicationStatusChecker from '@/components/ApplicationStatusChecker';

interface Application {
  id: string;
  cardNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  nationality: string;
  alternativeNumber?: string;
  mobileNumber: string;
  idNumber: string;
  gender: string;
  race: string;
  period: string;
  employed: string;
  qualification: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3?: string;
  wardNo: string;
  province: string;
  subRegion: string;
  membershipStatus: string;
  signature: string;
  submittedDate: string;
  activated: boolean;
  declarationName?: string;
}

interface IndexProps {
  user?: any;
}

const Index = ({ user }: IndexProps) => {
  const [showSuccess, setShowSuccess] = useState(false);
  const [showStatusChecker, setShowStatusChecker] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const generateCardNumber = (): string => {
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `OD${timestamp.slice(-6)}${random}`;
  };

  const generatePayFastPaymentUrl = (application: Application) => {
    const payfastMerchantId = localStorage.getItem('dudula-payfast-merchant-id');
    const payfastMerchantKey = localStorage.getItem('dudula-payfast-merchant-key');
    
    if (!payfastMerchantId || !payfastMerchantKey) {
      // Fallback to success if PayFast not configured
      setShowSuccess(true);
      return;
    }

    const currentUrl = window.location.origin;
    const params = new URLSearchParams({
      merchant_id: payfastMerchantId,
      merchant_key: payfastMerchantKey,
      amount: '100.00',
      item_name: 'Operation Dudula Membership Application Fee',
      item_description: `Membership application fee for ${application.firstName} ${application.lastName}`,
      return_url: `${currentUrl}/payment-result?payment_status=COMPLETE&m_payment_id=${application.id}`,
      cancel_url: `${currentUrl}/payment-result?payment_status=CANCELLED&m_payment_id=${application.id}`,
      notify_url: `${currentUrl}/payment-result`,
      name_first: application.firstName,
      name_last: application.lastName,
      email_address: application.email,
      m_payment_id: application.id,
      payment_method: 'cc'
    });

    const payfastUrl = `https://sandbox.payfast.co.za/eng/process?${params.toString()}`;
    window.location.href = payfastUrl;
  };

  const handleFormSubmit = async (data: any) => {
    const cardNumber = generateCardNumber();
    const application: Application = {
      id: Date.now().toString(),
      cardNumber,
      ...data,
      submittedDate: new Date().toISOString(),
      activated: false,
    };

    try {
      // Save to Supabase database
      const { error } = await supabase
        .from('applications')
        .insert([{
          card_number: application.cardNumber,
          first_name: application.firstName,
          last_name: application.lastName,
          email: application.email,
          nationality: application.nationality,
          alternative_number: application.alternativeNumber,
          mobile_number: application.mobileNumber,
          id_number: application.idNumber,
          gender: application.gender,
          race: application.race,
          period: application.period,
          employed: application.employed,
          qualification: application.qualification,
          address_line1: application.addressLine1,
          address_line2: application.addressLine2,
          address_line3: application.addressLine3,
          ward_no: application.wardNo,
          province: application.province,
          sub_region: application.subRegion,
          membership_status: application.membershipStatus,
          signature: application.signature,
          declaration_name: application.declarationName,
          activated: application.activated
        }]);

      if (error) {
        console.error('Error saving to database:', error);
        // Fallback to localStorage
        const existingApplications = JSON.parse(localStorage.getItem('dudula-applications') || '[]');
        const updatedApplications = [...existingApplications, application];
        localStorage.setItem('dudula-applications', JSON.stringify(updatedApplications));
      } else {
        // Also save to localStorage for backwards compatibility
        const existingApplications = JSON.parse(localStorage.getItem('dudula-applications') || '[]');
        const updatedApplications = [...existingApplications, application];
        localStorage.setItem('dudula-applications', JSON.stringify(updatedApplications));
      }

      toast({
        title: "Application Submitted Successfully!",
        description: "Redirecting to payment page...",
      });

      // Show success message first
      setShowSuccess(true);
      
      // Show payment message after a short delay
      setTimeout(() => {
        toast({
          title: "Payment Required",
          description: "Please proceed to payment below to complete your membership.",
          variant: "default",
        });
        
        // Redirect to external payment page
        setTimeout(() => {
          window.location.href = 'https://operationdudula.org.za/Payment';
        }, 1000);
      }, 2000);
    } catch (error) {
      console.error('Error submitting application:', error);
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleNewApplication = () => {
    setShowSuccess(false);
  };

  const handleBack = () => {
    // Optional: Add any cleanup logic here
    console.log('Back button clicked');
  };

  if (showSuccess) {
    return <SuccessMessage onNewApplication={handleNewApplication} />;
  }

  return (
    <div className="relative">
      {/* Navigation Header */}
      <div className="bg-white/95 backdrop-blur border-b shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-primary">Operation Dudula</h1>
          <div className="flex items-center gap-4">
            <Button 
              variant="outline"
              onClick={() => navigate('/application-status')}
              className="text-sm"
            >
              Check Status
            </Button>
            {user ? (
              <Button 
                onClick={() => navigate('/profile')}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold"
              >
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
            ) : (
              <Button 
                onClick={() => navigate('/auth')}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold"
              >
                Login / Sign Up
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary/10 to-accent/10 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            Operation Dudula
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join our movement for community empowerment and social justice. Choose your membership type below.
          </p>
        </div>
      </div>

      {/* Membership Options */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Operation Dudula Membership */}
          <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Operation Dudula Membership</h3>
              <p className="text-muted-foreground mb-6">
                Join the main Operation Dudula movement for community empowerment and advocacy.
              </p>
              <Button asChild className="w-full">
                <Link to="/membership">Apply Now</Link>
              </Button>
            </div>
          </div>

          {/* Youth League */}
          <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-accent/20 hover:border-accent/40 transition-colors">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-bold text-accent mb-3">Youth League</h3>
              <p className="text-muted-foreground mb-6">
                Young leaders driving change. Requires Operation Dudula membership first.
              </p>
              <Button asChild variant="outline" className="w-full">
                <Link to="/youth-league">Apply for Youth League</Link>
              </Button>
            </div>
          </div>

          {/* Men's League */}
          <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-blue-200 hover:border-blue-400 transition-colors">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-600 mb-3">Men's League</h3>
              <p className="text-muted-foreground mb-6">
                Brotherhood for social action. Requires Operation Dudula membership first.
              </p>
              <Button asChild variant="outline" className="w-full">
                <Link to="/mens-league">Apply for Men's League</Link>
              </Button>
            </div>
          </div>

          {/* Women's League */}
          <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-pink-200 hover:border-pink-400 transition-colors">
            <div className="text-center">
              <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="h-8 w-8 text-pink-600" />
              </div>
              <h3 className="text-xl font-bold text-pink-600 mb-3">Women's League</h3>
              <p className="text-muted-foreground mb-6">
                Empowering women in leadership. Requires Operation Dudula membership first.
              </p>
              <Button asChild variant="outline" className="w-full">
                <Link to="/womens-league">Apply for Women's League</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="text-center mt-12">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 max-w-3xl mx-auto">
            <h3 className="text-lg font-semibold text-yellow-800 mb-2">Important Notice</h3>
            <p className="text-yellow-700">
              All applications require login to access. Please create an account or sign in to continue with your membership application process.
            </p>
          </div>
        </div>
      </div>

      {/* Application Status Checker Modal */}
      <ApplicationStatusChecker 
        isOpen={showStatusChecker}
        onClose={() => setShowStatusChecker(false)}
      />
    </div>
  );
};

export default Index;
