import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Home, Download } from 'lucide-react';
import * as XLSX from 'xlsx';

export default function YouthLeagueApplicationsPage() {
  const [applications, setApplications] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('youth_league_memberships')
        .select('*')
        .order('submitted_date', { ascending: false });

      if (error) {
        console.error('Error loading applications:', error);
        toast({
          title: "Error",
          description: "Failed to load applications",
          variant: "destructive",
        });
      } else {
        setApplications(data || []);
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load applications",
        variant: "destructive",
      });
    }
  };

  const downloadExcel = () => {
    const exportData = applications.map(app => ({
      'Card Number': app.operation_dudula_card_number || 'Not assigned',
      'First Name': app.first_name,
      'Last Name': app.last_name,
      'Email': app.email,
      'ID Number': app.id_number,
      'Membership Status': app.membership_status,
      'Submitted Date': new Date(app.submitted_date).toLocaleDateString(),
      'Activated': app.activated ? 'Yes' : 'No',
      'Expires At': new Date(app.expires_at).toLocaleDateString()
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Youth League Applications');
    XLSX.writeFile(wb, `youth-league-applications-${new Date().toISOString().split('T')[0]}.xlsx`);
    
    toast({
      title: "Export Successful",
      description: "Youth League applications exported to Excel file",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-primary">Youth League Applications</h1>
            <p className="text-muted-foreground">Manage youth league membership applications</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => window.location.href = '/'}>
              <Home className="h-4 w-4 mr-2" />
              Home
            </Button>
            <Button onClick={downloadExcel} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Export Excel
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{applications.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Activated</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">
                {applications.filter(app => app.activated).length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">
                {applications.filter(app => !app.activated).length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Verified</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-info">
                {applications.filter(app => app.membership_status === 'verified').length}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Applications List</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {applications.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No applications found</p>
              ) : (
                applications.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg bg-muted/50">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${app.membership_status === 'verified' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        <div className="font-medium">{app.first_name} {app.last_name}</div>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Card: {app.operation_dudula_card_number || 'Not assigned'} | {app.email}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Submitted: {new Date(app.submitted_date).toLocaleDateString()} | 
                        Expires: {new Date(app.expires_at).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={app.activated ? "default" : "secondary"}>
                        {app.activated ? "Activated" : "Pending"}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}