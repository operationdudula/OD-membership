import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Search, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';

interface ActivatedApplication {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  idNumber: string;
  mobileNumber: string;
  province: string;
  subRegion: string;
  membershipStatus: string;
  submittedDate: string;
  cardNumber?: string;
  operationDudulaCardNumber?: string;
}

export default function ActivatedApplicants() {
  const [activatedApplications, setActivatedApplications] = useState<ActivatedApplication[]>([]);
  const [filteredApplications, setFilteredApplications] = useState<ActivatedApplication[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadActivatedApplications();
  }, []);

  useEffect(() => {
    filterApplications();
  }, [searchTerm, activatedApplications]);

  const loadActivatedApplications = async () => {
    setIsLoading(true);
    try {
      const allApplications: ActivatedApplication[] = [];

      // Load from main applications table
      const { data: mainApps, error: mainError } = await supabase
        .from('applications')
        .select('*')
        .eq('activated', true);

      if (mainApps && !mainError) {
        allApplications.push(...mainApps.map(app => ({
          id: app.id,
          firstName: app.first_name,
          lastName: app.last_name,
          email: app.email,
          idNumber: app.id_number,
          mobileNumber: app.mobile_number,
          province: app.province,
          subRegion: app.sub_region,
          membershipStatus: app.membership_status,
          submittedDate: app.submitted_date,
          cardNumber: app.card_number,
          operationDudulaCardNumber: app.card_number
        })));
      }

      // Load from mens league table
      const { data: mensApps, error: mensError } = await supabase
        .from('mens_league_memberships')
        .select('*')
        .eq('activated', true);

      if (mensApps && !mensError) {
        allApplications.push(...mensApps.map(app => ({
          id: app.id,
          firstName: app.first_name,
          lastName: app.last_name,
          email: app.email,
          idNumber: app.id_number,
          mobileNumber: '',
          province: 'Mens League',
          subRegion: 'Mens League',
          membershipStatus: app.membership_status,
          submittedDate: app.submitted_date,
          cardNumber: '',
          operationDudulaCardNumber: app.operation_dudula_card_number
        })));
      }

      // Load from womens league table
      const { data: womensApps, error: womensError } = await supabase
        .from('womens_league_memberships')
        .select('*')
        .eq('activated', true);

      if (womensApps && !womensError) {
        allApplications.push(...womensApps.map(app => ({
          id: app.id,
          firstName: app.first_name,
          lastName: app.last_name,
          email: app.email,
          idNumber: app.id_number,
          mobileNumber: '',
          province: 'Womens League',
          subRegion: 'Womens League',
          membershipStatus: app.membership_status,
          submittedDate: app.submitted_date,
          cardNumber: '',
          operationDudulaCardNumber: app.operation_dudula_card_number
        })));
      }

      // Load from youth league table
      const { data: youthApps, error: youthError } = await supabase
        .from('youth_league_memberships')
        .select('*')
        .eq('activated', true);

      if (youthApps && !youthError) {
        allApplications.push(...youthApps.map(app => ({
          id: app.id,
          firstName: app.first_name,
          lastName: app.last_name,
          email: app.email,
          idNumber: app.id_number,
          mobileNumber: '',
          province: 'Youth League',
          subRegion: 'Youth League',
          membershipStatus: app.membership_status,
          submittedDate: app.submitted_date,
          cardNumber: '',
          operationDudulaCardNumber: app.operation_dudula_card_number
        })));
      }

      setActivatedApplications(allApplications);
    } catch (error) {
      console.error('Error loading activated applications:', error);
      toast({
        title: "Error",
        description: "Failed to load activated applications",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filterApplications = () => {
    if (!searchTerm) {
      setFilteredApplications(activatedApplications);
      return;
    }

    const filtered = activatedApplications.filter(app =>
      app.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.idNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (app.cardNumber && app.cardNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (app.operationDudulaCardNumber && app.operationDudulaCardNumber.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    setFilteredApplications(filtered);
  };

  const exportToExcel = () => {
    const exportData = filteredApplications.map(app => ({
      'ID Number': app.idNumber,
      'First Name': app.firstName,
      'Last Name': app.lastName,
      'Email': app.email,
      'Mobile Number': app.mobileNumber,
      'Province': app.province,
      'Sub Region': app.subRegion,
      'Card Number': app.cardNumber || app.operationDudulaCardNumber || '',
      'Membership Status': app.membershipStatus,
      'Activated Date': new Date(app.submittedDate).toLocaleDateString()
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Activated Applications');
    XLSX.writeFile(wb, `activated-applications-${new Date().toISOString().split('T')[0]}.xlsx`);
    
    toast({
      title: "Export Successful",
      description: `Exported ${filteredApplications.length} activated applications`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="container mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => window.history.back()}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
            <h1 className="text-3xl font-bold text-primary">Activated Applicants</h1>
          </div>
          <Button onClick={exportToExcel} className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export to Excel
          </Button>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Activated Applications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Search by ID number, name, email, or card number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground mb-4">
              Showing {filteredApplications.length} of {activatedApplications.length} activated applications
            </div>
            
            {filteredApplications.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">
                    {searchTerm ? 'No activated applications match your search.' : 'No activated applications found.'}
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredApplications.map((application) => (
                <Card key={application.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <h3 className="font-semibold text-lg">
                          {application.firstName} {application.lastName}
                        </h3>
                        <p className="text-sm text-muted-foreground">{application.email}</p>
                        <p className="text-sm text-muted-foreground">ID: {application.idNumber}</p>
                      </div>
                      <div>
                        <p className="text-sm"><strong>Province:</strong> {application.province}</p>
                        <p className="text-sm"><strong>Sub Region:</strong> {application.subRegion}</p>
                        <p className="text-sm"><strong>Mobile:</strong> {application.mobileNumber}</p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Badge variant="outline" className="w-fit">
                          {application.membershipStatus}
                        </Badge>
                        {(application.cardNumber || application.operationDudulaCardNumber) && (
                          <p className="text-sm"><strong>Card:</strong> {application.cardNumber || application.operationDudulaCardNumber}</p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Activated: {new Date(application.submittedDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}