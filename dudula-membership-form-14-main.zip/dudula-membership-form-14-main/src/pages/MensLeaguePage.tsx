import React, { useState } from 'react';
import { MensLeagueForm } from '@/components/MensLeagueForm';
import { SuccessMessage } from '@/components/SuccessMessage';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const MensLeaguePage = () => {
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();

  const handleFormSubmit = (data: any) => {
    setShowSuccess(true);
  };

  const handleNewApplication = () => {
    setShowSuccess(false);
  };

  if (showSuccess) {
    return <SuccessMessage onNewApplication={handleNewApplication} />;
  }

  return (
    <div className="relative">
      {/* Navigation Header */}
      <div className="bg-white/95 backdrop-blur border-b shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-primary">Operation Dudula - Men's League</h1>
          <div className="flex items-center gap-4">
            <Button 
              variant="outline"
              onClick={() => navigate('/')}
              className="text-sm"
            >
              Back to Home
            </Button>
            <Button 
              variant="outline"
              onClick={() => navigate('/application-status')}
              className="text-sm"
            >
              Check Application Status
            </Button>
          </div>
        </div>
      </div>
      <MensLeagueForm onSubmit={handleFormSubmit} />
    </div>
  );
};

export default MensLeaguePage;