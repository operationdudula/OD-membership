import React from 'react';
import { MembershipForm } from '@/components/MembershipForm';
import { Button } from '@/components/ui/button';
import { Home } from 'lucide-react';

const MembershipPage = () => {
  const handleFormSubmit = (data: any) => {
    console.log('Membership form submitted:', data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto px-4 py-4">
        <Button 
          variant="outline" 
          onClick={() => window.location.href = '/'}
          className="mb-4 flex items-center gap-2"
        >
          <Home className="h-4 w-4" />
          Back to Home
        </Button>
      </div>
      <MembershipForm onSubmit={handleFormSubmit} />
    </div>
  );
};

export default MembershipPage;