import React, { useState } from 'react';
import { WomensLeagueForm } from '@/components/WomensLeagueForm';
import { WomensLeagueStatusChecker } from '@/components/WomensLeagueStatusChecker';
import { Button } from '@/components/ui/button';
import { Home, Search } from 'lucide-react';

const WomensLeaguePage = () => {
  const [showStatusChecker, setShowStatusChecker] = useState(false);

  const handleFormSubmit = (data: any) => {
    console.log('Women\'s league form submitted:', data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto px-4 py-4">
        <div className="mb-4 flex items-center gap-2">
          <Button 
            variant="outline" 
            onClick={() => window.location.href = '/'}
            className="flex items-center gap-2"
          >
            <Home className="h-4 w-4" />
            Back to Home
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setShowStatusChecker(true)}
            className="flex items-center gap-2"
          >
            <Search className="h-4 w-4" />
            Check Application Status
          </Button>
        </div>
      </div>
      <WomensLeagueForm />
      <WomensLeagueStatusChecker 
        isOpen={showStatusChecker} 
        onClose={() => setShowStatusChecker(false)} 
      />
    </div>
  );
};

export default WomensLeaguePage;