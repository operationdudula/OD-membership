
import React, { useState, useEffect } from 'react';
import { AdminLogin } from '@/components/AdminLogin';
import { AdminDashboard } from '@/components/AdminDashboard';
import { supabase, testSupabaseConnection } from '@/integrations/supabase/client';

interface Application {
  id: string;
  cardNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  nationality: string;
  alternativeNumber?: string;
  mobileNumber: string;
  idNumber: string;
  gender: string;
  race: string;
  period: string;
  employed: string;
  qualification: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3?: string;
  wardNo: string;
  province: string;
  subRegion: string;
  membershipStatus: string;
  signature: string;
  submittedDate: string;
  activated: boolean;
  declarationName?: string;
}

const AdminPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [applications, setApplications] = useState<any[]>([]);
  const [isSupabaseConnected, setIsSupabaseConnected] = useState<boolean | null>(null);

  useEffect(() => {
    const loadAllApplications = async () => {
      // Test Supabase connection first
      const connectionStatus = await testSupabaseConnection();
      setIsSupabaseConnected(connectionStatus);
      
      try {
        // Load from Supabase
        const [dudulaApps, youthApps, mensApps, womensApps] = await Promise.all([
          supabase.from('applications').select('*').then(({ data }) => data?.map(app => ({ ...app, type: 'Operation Dudula' })) || []),
          supabase.from('youth_league_memberships').select('*').then(({ data }) => data?.map(app => ({ ...app, type: 'Youth League' })) || []),
          supabase.from('mens_league_memberships').select('*').then(({ data }) => data?.map(app => ({ ...app, type: 'Men\'s League' })) || []),
          supabase.from('womens_league_memberships').select('*').then(({ data }) => data?.map(app => ({ ...app, type: 'Women\'s League' })) || [])
        ]);
        
        const allApps = [...dudulaApps, ...youthApps, ...mensApps, ...womensApps];
        setApplications(allApps);
        
        // Also load from localStorage as fallback
        const savedApplications = localStorage.getItem('dudula-applications');
        if (savedApplications && allApps.length === 0) {
          const localApps = JSON.parse(savedApplications).map((app: any) => ({ ...app, type: 'Operation Dudula (Local)' }));
          setApplications(localApps);
        }
      } catch (error) {
        console.error('Error loading applications:', error);
        setIsSupabaseConnected(false);
        // Fallback to localStorage
        const savedApplications = localStorage.getItem('dudula-applications');
        if (savedApplications) {
          const localApps = JSON.parse(savedApplications).map((app: any) => ({ ...app, type: 'Operation Dudula (Local)' }));
          setApplications(localApps);
        }
      }
    };
    
    loadAllApplications();
  }, []);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleActivateApplication = (id: string) => {
    const updatedApplications = applications.map(app =>
      app.id === id ? { ...app, activated: true } : app
    );
    setApplications(updatedApplications);
    localStorage.setItem('dudula-applications', JSON.stringify(updatedApplications));
  };

  const handleDeleteApplication = (id: string) => {
    const updatedApplications = applications.filter(app => app.id !== id);
    setApplications(updatedApplications);
    localStorage.setItem('dudula-applications', JSON.stringify(updatedApplications));
  };

  if (!isAuthenticated) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  return (
    <div>
      {/* Connection Status Banner */}
      <div className={`w-full p-2 text-center text-sm font-medium ${
        isSupabaseConnected === true ? 'bg-green-100 text-green-800' : 
        isSupabaseConnected === false ? 'bg-red-100 text-red-800' : 
        'bg-yellow-100 text-yellow-800'
      }`}>
        {isSupabaseConnected === true ? '✅ Connected to Supabase Database' : 
         isSupabaseConnected === false ? '❌ Disconnected from Supabase Database' : 
         '🔄 Checking Supabase Connection...'}
      </div>
      
      <AdminDashboard 
        applications={applications} 
        onActivateApplication={handleActivateApplication}
        onDeleteApplication={handleDeleteApplication}
        onLogout={handleLogout} 
      />
    </div>
  );
};

export default AdminPage;
