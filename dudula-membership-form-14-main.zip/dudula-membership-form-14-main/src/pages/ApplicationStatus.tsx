import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Search, Calendar, MapPin, Mail, Phone, User, ArrowLeft, Home } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';

interface Application {
  id: string;
  cardNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  nationality: string;
  alternativeNumber?: string;
  mobileNumber: string;
  idNumber: string;
  gender: string;
  race: string;
  period: string;
  employed: string;
  qualification: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3?: string;
  wardNo: string;
  province: string;
  subRegion: string;
  membershipStatus: string;
  signature: string;
  submittedDate: string;
  activated: boolean;
  declarationName?: string;
  verified?: boolean;
}

const ApplicationStatus = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [foundApplications, setFoundApplications] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      toast({
        title: "Search Required",
        description: "Please enter card number",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    setFoundApplications([]);
    
    try {
      // Search in all three databases
      const searchPromises = [
        // Operation Dudula applications
        supabase
          .from('applications')
          .select('*')
          .or(`card_number.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%,id_number.ilike.%${searchTerm}%,mobile_number.ilike.%${searchTerm}%,alternative_number.ilike.%${searchTerm}%`)
          .then(({ data }) => data?.map(app => ({ ...app, type: 'Operation Dudula' })) || []),
        
        // Youth League applications
        supabase
          .from('youth_league_memberships')
          .select('*')
          .or(`operation_dudula_card_number.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%,id_number.ilike.%${searchTerm}%`)
          .then(({ data }) => data?.map(app => ({ ...app, type: 'Youth League' })) || []),
        
        // Men's League applications
        supabase
          .from('mens_league_memberships')
          .select('*')
          .or(`operation_dudula_card_number.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%,id_number.ilike.%${searchTerm}%`)
          .then(({ data }) => data?.map(app => ({ ...app, type: 'Men\'s League' })) || []),
        
        // Women's League applications
        supabase
          .from('womens_league_memberships')
          .select('*')
          .or(`operation_dudula_card_number.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%,id_number.ilike.%${searchTerm}%`)
          .then(({ data }) => data?.map(app => ({ ...app, type: 'Women\'s League' })) || [])
      ];

      const results = await Promise.all(searchPromises);
      const allResults = results.flat();

      // Fallback to localStorage search
      if (allResults.length === 0) {
        const localApplications = JSON.parse(localStorage.getItem('dudula-applications') || '[]');
        const localFound = localApplications.filter((app: any) => 
          app.cardNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          app.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          app.idNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          app.mobileNumber?.includes(searchTerm) ||
          app.alternativeNumber?.includes(searchTerm)
        ).map((app: any) => ({ ...app, type: 'Operation Dudula (Local)' }));
        
        allResults.push(...localFound);
      }
      
      setFoundApplications(allResults);
      
      if (allResults.length === 0) {
        toast({
          title: "No Applications Found",
          description: "No applications found matching your search criteria.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Applications Found",
          description: `Found ${allResults.length} application(s)`,
        });
      }
    } catch (error) {
      console.error('Search error:', error);
      toast({
        title: "Search Error",
        description: "An error occurred while searching. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const calculateExpiryDate = (submittedDate: string) => {
    const submitted = new Date(submittedDate);
    const expiry = new Date(submitted);
    expiry.setFullYear(expiry.getFullYear() + 5); // 5 years from submission
    return expiry.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 py-8">
      <div className="container mx-auto max-w-4xl px-4">
        {/* Back to Home Button */}
        <div className="mb-6">
          <Button
            variant="outline"
            onClick={() => navigate('/')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </div>

        <Card className="shadow-xl border-0 bg-white/95 backdrop-blur mb-8">
          <CardHeader className="bg-gradient-to-r from-primary to-primary-light text-white rounded-t-lg">
            <div className="flex items-center justify-center gap-2">
              <Home className="h-6 w-6" />
              <CardTitle className="text-2xl font-bold">
                Check Application Status
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              <div>
                <Label htmlFor="searchTerm">Enter Email, Mobile Number, or Card Number</Label>
                <div className="flex gap-4 mt-2">
                  <Input
                    id="searchTerm"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search across all membership types"
                    className="flex-1"
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  />
                  <Button 
                    onClick={handleSearch} 
                    disabled={isSearching}
                    className="flex items-center gap-2"
                  >
                    <Search className="h-4 w-4" />
                    {isSearching ? 'Searching...' : 'Search All'}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {foundApplications.length > 0 && foundApplications.map((foundApplication, index) => (
          <Card key={index} className="shadow-xl border-0 bg-white/95 backdrop-blur mb-6">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl">{foundApplication.type} Membership</CardTitle>
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${
                    (foundApplication.membership_status === 'verified' || foundApplication.membershipStatus === 'verified' || foundApplication.verified) 
                      ? 'bg-green-500' 
                      : 'bg-red-500'
                  }`}></div>
                  <Badge variant={foundApplication.activated ? "default" : "secondary"}>
                    {foundApplication.activated ? "Activated" : "Pending"}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-primary border-b pb-2">Personal Information</h3>
                  
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Name:</span>
                    <span>{foundApplication.first_name || foundApplication.firstName} {foundApplication.last_name || foundApplication.lastName}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Email:</span>
                    <span>{foundApplication.email}</span>
                  </div>
                  
                  {foundApplication.mobile_number || foundApplication.mobileNumber ? (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">Mobile:</span>
                      <span>{foundApplication.mobile_number || foundApplication.mobileNumber}</span>
                    </div>
                  ) : null}
                  
                  {(foundApplication.alternative_number || foundApplication.alternativeNumber) && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">Alternative:</span>
                      <span>{foundApplication.alternative_number || foundApplication.alternativeNumber}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2">
                    <span className="font-medium">ID Number:</span>
                    <span>{foundApplication.id_number || foundApplication.idNumber}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Card Number:</span>
                    <span>{foundApplication.card_number || foundApplication.operation_dudula_card_number || foundApplication.cardNumber}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-primary border-b pb-2">Status Information</h3>
                  
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Submitted:</span>
                    <span>{new Date(foundApplication.submitted_date || foundApplication.submittedDate).toLocaleDateString()}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Expires:</span>
                    <span>
                      {foundApplication.expires_at 
                        ? new Date(foundApplication.expires_at).toLocaleDateString()
                        : calculateExpiryDate(foundApplication.submitted_date || foundApplication.submittedDate)
                      }
                    </span>
                  </div>
                  
                  {(foundApplication.province || foundApplication.type === 'Operation Dudula') && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">Province:</span>
                      <span>{foundApplication.province || 'N/A'}</span>
                    </div>
                  )}
                  
                  {(foundApplication.subRegion || foundApplication.sub_region) && (
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Sub Region:</span>
                      <span>{foundApplication.sub_region || foundApplication.subRegion}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Membership Status:</span>
                    <span>{foundApplication.membership_status || foundApplication.membershipStatus}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-medium">Verification Status:</span>
                    <Badge variant={
                      (foundApplication.membership_status === 'verified' || foundApplication.membershipStatus === 'verified' || foundApplication.verified) 
                        ? "default" 
                        : "destructive"
                    }>
                      {(foundApplication.membership_status === 'verified' || foundApplication.membershipStatus === 'verified' || foundApplication.verified) 
                        ? "Verified" 
                        : "Not Verified"
                      }
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Verification Notice */}
              {!(foundApplication.membership_status === 'verified' || foundApplication.membershipStatus === 'verified' || foundApplication.verified) && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <h4 className="font-medium text-yellow-800 mb-2">Verification Required</h4>
                  <p className="text-yellow-700 text-sm">
                    Your application requires verification. This will be done automatically when you complete payment.
                  </p>
                </div>
              )}

              {/* Address Information - Only for Operation Dudula */}
              {foundApplication.type === 'Operation Dudula' && (
                <div>
                  <h3 className="text-lg font-semibold text-primary border-b pb-2 mb-4">Address Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <span className="font-medium">Address Line 1:</span>
                      <p className="text-muted-foreground">{foundApplication.address_line1 || foundApplication.addressLine1}</p>
                    </div>
                    <div>
                      <span className="font-medium">Address Line 2:</span>
                      <p className="text-muted-foreground">{foundApplication.address_line2 || foundApplication.addressLine2}</p>
                    </div>
                    {(foundApplication.address_line3 || foundApplication.addressLine3) && (
                      <div>
                        <span className="font-medium">Address Line 3:</span>
                        <p className="text-muted-foreground">{foundApplication.address_line3 || foundApplication.addressLine3}</p>
                      </div>
                    )}
                    <div>
                      <span className="font-medium">Ward No:</span>
                      <p className="text-muted-foreground">{foundApplication.ward_no || foundApplication.wardNo}</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ApplicationStatus;
