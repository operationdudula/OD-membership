import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Home, Download } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
// import { regionData } from '@/utils/regionData';
import * as XLSX from 'xlsx';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF6B6B', '#4ECDC4'];

export default function ApplicationsByProvince() {
  const [applications, setApplications] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    try {
      // Load from all tables
      const [mainApps, mensApps, womensApps, youthApps] = await Promise.all([
        supabase.from('applications').select('*'),
        supabase.from('mens_league_memberships').select('*'),
        supabase.from('womens_league_memberships').select('*'),
        supabase.from('youth_league_memberships').select('*')
      ]);

      const allApplications = [
        ...(mainApps.data || []).map(app => ({ ...app, type: 'main' })),
        ...(mensApps.data || []).map(app => ({ ...app, type: 'mens', province: 'Unknown' })),
        ...(womensApps.data || []).map(app => ({ ...app, type: 'womens', province: 'Unknown' })),
        ...(youthApps.data || []).map(app => ({ ...app, type: 'youth', province: 'Unknown' }))
      ];

      setApplications(allApplications);
    } catch (error) {
      console.error('Error loading applications:', error);
      toast({
        title: "Error",
        description: "Failed to load applications",
        variant: "destructive",
      });
    }
  };

  const getProvinceData = () => {
    const provinceStats = applications.reduce((acc, app) => {
      const province = app.province || 'Unknown';
      if (!acc[province]) {
        acc[province] = { name: province, value: 0, regions: {} };
      }
      acc[province].value++;
      
      // Count by sub-region
      const subRegion = app.sub_region || 'Unknown';
      if (!acc[province].regions[subRegion]) {
        acc[province].regions[subRegion] = 0;
      }
      acc[province].regions[subRegion]++;
      
      return acc;
    }, {} as Record<string, { name: string; value: number; regions: Record<string, number> }>);

    return Object.values(provinceStats);
  };

  const getRegionPerformanceData = () => {
    const regionStats = applications.reduce((acc, app) => {
      const province = app.province || 'Unknown';
      const subRegion = app.sub_region || 'Unknown';
      const key = `${province} - ${subRegion}`;
      
      if (!acc[key]) {
        acc[key] = { name: key, applications: 0, activated: 0 };
      }
      acc[key].applications++;
      if (app.activated) {
        acc[key].activated++;
      }
      
      return acc;
    }, {} as Record<string, { name: string; applications: number; activated: number }>);

    return Object.values(regionStats).map((region: any) => ({
      name: region.name,
      applications: region.applications,
      activated: region.activated,
      activationRate: region.applications > 0 ? ((region.activated / region.applications) * 100).toFixed(1) : 0
    }));
  };

  const downloadExcel = () => {
    const provinceData = getProvinceData();
    const regionData = getRegionPerformanceData();
    
    const wb = XLSX.utils.book_new();
    
    // Province summary sheet
    const provinceSheet = XLSX.utils.json_to_sheet(provinceData.map(p => ({
      Province: (p as any).name,
      'Total Applications': (p as any).value
    })));
    XLSX.utils.book_append_sheet(wb, provinceSheet, 'Province Summary');
    
    // Region performance sheet
    const regionSheet = XLSX.utils.json_to_sheet(regionData.map((r: any) => ({
      'Province - Region': r.name,
      'Total Applications': r.applications,
      'Activated Applications': r.activated,
      'Activation Rate (%)': r.activationRate
    })));
    XLSX.utils.book_append_sheet(wb, regionSheet, 'Region Performance');
    
    XLSX.writeFile(wb, `applications-by-province-${new Date().toISOString().split('T')[0]}.xlsx`);
    
    toast({
      title: "Export Successful",
      description: "Province analytics exported to Excel file",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-primary">Applications by Province</h1>
            <p className="text-muted-foreground">Provincial application analytics and regional performance</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => window.location.href = 'https://operationdudula.org.za/'}>
              <Home className="h-4 w-4 mr-2" />
              Return to Home
            </Button>
            <Button onClick={downloadExcel} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Export Excel
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Province Distribution Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Applications by Province</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={getProvinceData()}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {getProvinceData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Regional Performance Line Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Regional Performance by Province</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={getRegionPerformanceData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="name" 
                      angle={-45}
                      textAnchor="end"
                      height={120}
                      interval={0}
                      fontSize={10}
                    />
                    <YAxis />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey="applications" 
                      stroke="#8884d8" 
                      name="Total Applications"
                      strokeWidth={2}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="activated" 
                      stroke="#82ca9d" 
                      name="Activated Applications"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Province Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {getProvinceData().map((province, index) => (
            <Card key={(province as any).name}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">{(province as any).name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" style={{ color: COLORS[index % COLORS.length] }}>
                  {(province as any).value}
                </div>
                <p className="text-xs text-muted-foreground">applications</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}