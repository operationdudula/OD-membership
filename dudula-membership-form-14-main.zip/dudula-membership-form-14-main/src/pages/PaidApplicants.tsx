import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Search, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface PaidApplicant {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  id_number: string;
  created_at: string;
}

const PaidApplicants = () => {
  const [applicants, setApplicants] = useState<PaidApplicant[]>([]);
  const [filteredApplicants, setFilteredApplicants] = useState<PaidApplicant[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadApplicants();
  }, []);

  useEffect(() => {
    filterApplicants();
  }, [searchTerm, applicants]);

  const loadApplicants = async () => {
    try {
      const { data, error } = await supabase
        .from('paid_applicants')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      setApplicants(data || []);
    } catch (error) {
      console.error('Error loading applicants:', error);
      toast({
        title: "Error",
        description: "Failed to load paid applicants.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filterApplicants = () => {
    if (searchTerm.trim() === '') {
      setFilteredApplicants(applicants);
    } else {
      const filtered = applicants.filter(applicant =>
        applicant.id_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        applicant.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        applicant.phone_number.includes(searchTerm)
      );
      setFilteredApplicants(filtered);
    }
  };

  const deleteApplicant = async (id: string) => {
    try {
      const { error } = await supabase
        .from('paid_applicants')
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      toast({
        title: "Success",
        description: "Applicant deleted successfully.",
      });

      // Reload applicants
      loadApplicants();
    } catch (error) {
      console.error('Error deleting applicant:', error);
      toast({
        title: "Error",
        description: "Failed to delete applicant.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            onClick={() => window.history.back()}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-primary">Paid Applicants</h1>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Applicants
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Search by ID number, email, or phone number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="text-center py-8">Loading...</div>
        ) : (
          <div className="space-y-4">
            {filteredApplicants.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">
                    {searchTerm ? 'No applicants found matching your search.' : 'No paid applicants found.'}
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredApplicants.map((applicant) => (
                <Card key={applicant.id}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1">
                        <div>
                          <p className="font-semibold text-primary">
                            {applicant.first_name} {applicant.last_name}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            ID: {applicant.id_number}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm">
                            <span className="font-medium">Email:</span> {applicant.email}
                          </p>
                          <p className="text-sm">
                            <span className="font-medium">Phone:</span> {applicant.phone_number}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">
                            Submitted: {new Date(applicant.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteApplicant(applicant.id)}
                        className="ml-4"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PaidApplicants;