import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { ensureSupabaseConnection } from './integrations/supabase/client'

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Failed to find the root element");

// Ensure Supabase connection on app start
ensureSupabaseConnection().then(() => {
  createRoot(rootElement).render(<App />);
}).catch((error) => {
  console.error('Failed to establish Supabase connection:', error);
  // Still render the app even if connection fails
  createRoot(rootElement).render(<App />);
});
